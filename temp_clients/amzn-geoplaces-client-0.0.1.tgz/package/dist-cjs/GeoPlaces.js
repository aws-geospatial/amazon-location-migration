"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GeoPlaces = void 0;
const GeoPlacesClient_1 = require("./GeoPlacesClient");
const AutocompleteCommand_1 = require("./commands/AutocompleteCommand");
const GeocodeCommand_1 = require("./commands/GeocodeCommand");
const GetPlaceCommand_1 = require("./commands/GetPlaceCommand");
const ReverseGeocodeCommand_1 = require("./commands/ReverseGeocodeCommand");
const SearchNearbyCommand_1 = require("./commands/SearchNearbyCommand");
const SearchTextCommand_1 = require("./commands/SearchTextCommand");
const SuggestCommand_1 = require("./commands/SuggestCommand");
const smithy_client_1 = require("@smithy/smithy-client");
const commands = {
    AutocompleteCommand: AutocompleteCommand_1.AutocompleteCommand,
    GeocodeCommand: GeocodeCommand_1.GeocodeCommand,
    GetPlaceCommand: GetPlaceCommand_1.GetPlaceCommand,
    ReverseGeocodeCommand: ReverseGeocodeCommand_1.ReverseGeocodeCommand,
    SearchNearbyCommand: SearchNearbyCommand_1.SearchNearbyCommand,
    SearchTextCommand: SearchTextCommand_1.SearchTextCommand,
    SuggestCommand: SuggestCommand_1.SuggestCommand,
};
class GeoPlaces extends GeoPlacesClient_1.GeoPlacesClient {
}
exports.GeoPlaces = GeoPlaces;
(0, smithy_client_1.createAggregatedClient)(commands, GeoPlaces);
