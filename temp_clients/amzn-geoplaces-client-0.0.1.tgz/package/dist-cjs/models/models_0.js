"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SuggestResponseFilterSensitiveLog = exports.SuggestResultItemFilterSensitiveLog = exports.SuggestPlaceResultFilterSensitiveLog = exports.SuggestRequestFilterSensitiveLog = exports.SearchTextResponseFilterSensitiveLog = exports.SearchTextResultItemFilterSensitiveLog = exports.SearchTextRequestFilterSensitiveLog = exports.SearchNearbyResponseFilterSensitiveLog = exports.SearchNearbyResultItemFilterSensitiveLog = exports.SearchNearbyRequestFilterSensitiveLog = exports.ReverseGeocodeResponseFilterSensitiveLog = exports.ReverseGeocodeResultItemFilterSensitiveLog = exports.ReverseGeocodeRequestFilterSensitiveLog = exports.GetPlaceResponseFilterSensitiveLog = exports.GetPlaceRequestFilterSensitiveLog = exports.GeocodeResponseFilterSensitiveLog = exports.GeocodeResultItemFilterSensitiveLog = exports.GeocodeRequestFilterSensitiveLog = exports.GeocodeQueryComponentsFilterSensitiveLog = exports.AutocompleteRequestFilterSensitiveLog = exports.FilterCircleFilterSensitiveLog = exports.AccessPointFilterSensitiveLog = exports.ValidationException = exports.ThrottlingException = exports.InternalServerException = exports.AccessDeniedException = void 0;
const GeoPlacesServiceException_1 = require("./GeoPlacesServiceException");
const smithy_client_1 = require("@smithy/smithy-client");
class AccessDeniedException extends GeoPlacesServiceException_1.GeoPlacesServiceException {
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts
        });
        this.name = "AccessDeniedException";
        this.$fault = "client";
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
exports.AccessDeniedException = AccessDeniedException;
class InternalServerException extends GeoPlacesServiceException_1.GeoPlacesServiceException {
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts
        });
        this.name = "InternalServerException";
        this.$fault = "server";
        this.$retryable = {};
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.Message = opts.Message;
    }
}
exports.InternalServerException = InternalServerException;
class ThrottlingException extends GeoPlacesServiceException_1.GeoPlacesServiceException {
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts
        });
        this.name = "ThrottlingException";
        this.$fault = "client";
        this.$retryable = {};
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
    }
}
exports.ThrottlingException = ThrottlingException;
class ValidationException extends GeoPlacesServiceException_1.GeoPlacesServiceException {
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts
        });
        this.name = "ValidationException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
        this.Reason = opts.Reason;
        this.FieldList = opts.FieldList;
    }
}
exports.ValidationException = ValidationException;
const AccessPointFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.AccessPointFilterSensitiveLog = AccessPointFilterSensitiveLog;
const FilterCircleFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Center && { Center: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.FilterCircleFilterSensitiveLog = FilterCircleFilterSensitiveLog;
const AutocompleteRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterBoundingBox && { FilterBoundingBox: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterCircle && { FilterCircle: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.AutocompleteRequestFilterSensitiveLog = AutocompleteRequestFilterSensitiveLog;
const GeocodeQueryComponentsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Country && { Country: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Region && { Region: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.SubRegion && { SubRegion: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Locality && { Locality: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.District && { District: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Street && { Street: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AddressNumber && { AddressNumber: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.PostalCode && { PostalCode: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.GeocodeQueryComponentsFilterSensitiveLog = GeocodeQueryComponentsFilterSensitiveLog;
const GeocodeRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.QueryComponents && { QueryComponents: (0, exports.GeocodeQueryComponentsFilterSensitiveLog)(obj.QueryComponents)
    }),
    ...(obj.BiasPosition && { BiasPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.GeocodeRequestFilterSensitiveLog = GeocodeRequestFilterSensitiveLog;
const GeocodeResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.GeocodeResultItemFilterSensitiveLog = GeocodeResultItemFilterSensitiveLog;
const GeocodeResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => (0, exports.GeocodeResultItemFilterSensitiveLog)(item))
    }),
});
exports.GeocodeResponseFilterSensitiveLog = GeocodeResponseFilterSensitiveLog;
const GetPlaceRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.PlaceId && { PlaceId: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.GetPlaceRequestFilterSensitiveLog = GetPlaceRequestFilterSensitiveLog;
const GetPlaceResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.GetPlaceResponseFilterSensitiveLog = GetPlaceResponseFilterSensitiveLog;
const ReverseGeocodeRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SearchPosition && { SearchPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.ReverseGeocodeRequestFilterSensitiveLog = ReverseGeocodeRequestFilterSensitiveLog;
const ReverseGeocodeResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.ReverseGeocodeResultItemFilterSensitiveLog = ReverseGeocodeResultItemFilterSensitiveLog;
const ReverseGeocodeResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => (0, exports.ReverseGeocodeResultItemFilterSensitiveLog)(item))
    }),
});
exports.ReverseGeocodeResponseFilterSensitiveLog = ReverseGeocodeResponseFilterSensitiveLog;
const SearchNearbyRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.SearchPosition && { SearchPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterBoundingBox && { FilterBoundingBox: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.SearchNearbyRequestFilterSensitiveLog = SearchNearbyRequestFilterSensitiveLog;
const SearchNearbyResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.SearchNearbyResultItemFilterSensitiveLog = SearchNearbyResultItemFilterSensitiveLog;
const SearchNearbyResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => (0, exports.SearchNearbyResultItemFilterSensitiveLog)(item))
    }),
});
exports.SearchNearbyResponseFilterSensitiveLog = SearchNearbyResponseFilterSensitiveLog;
const SearchTextRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.QueryId && { QueryId: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterBoundingBox && { FilterBoundingBox: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterCircle && { FilterCircle: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.SearchTextRequestFilterSensitiveLog = SearchTextRequestFilterSensitiveLog;
const SearchTextResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.SearchTextResultItemFilterSensitiveLog = SearchTextResultItemFilterSensitiveLog;
const SearchTextResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => (0, exports.SearchTextResultItemFilterSensitiveLog)(item))
    }),
});
exports.SearchTextResponseFilterSensitiveLog = SearchTextResponseFilterSensitiveLog;
const SuggestRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterBoundingBox && { FilterBoundingBox: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.FilterCircle && { FilterCircle: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: smithy_client_1.SENSITIVE_STRING
    }),
});
exports.SuggestRequestFilterSensitiveLog = SuggestRequestFilterSensitiveLog;
const SuggestPlaceResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: smithy_client_1.SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => (0, exports.AccessPointFilterSensitiveLog)(item))
    }),
});
exports.SuggestPlaceResultFilterSensitiveLog = SuggestPlaceResultFilterSensitiveLog;
const SuggestResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Place && { Place: (0, exports.SuggestPlaceResultFilterSensitiveLog)(obj.Place)
    }),
});
exports.SuggestResultItemFilterSensitiveLog = SuggestResultItemFilterSensitiveLog;
const SuggestResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => (0, exports.SuggestResultItemFilterSensitiveLog)(item))
    }),
});
exports.SuggestResponseFilterSensitiveLog = SuggestResponseFilterSensitiveLog;
