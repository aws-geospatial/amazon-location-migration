"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.de_SuggestCommand = exports.de_SearchTextCommand = exports.de_SearchNearbyCommand = exports.de_ReverseGeocodeCommand = exports.de_GetPlaceCommand = exports.de_GeocodeCommand = exports.de_AutocompleteCommand = exports.se_SuggestCommand = exports.se_SearchTextCommand = exports.se_SearchNearbyCommand = exports.se_ReverseGeocodeCommand = exports.se_GetPlaceCommand = exports.se_GeocodeCommand = exports.se_AutocompleteCommand = void 0;
const GeoPlacesServiceException_1 = require("../models/GeoPlacesServiceException");
const models_0_1 = require("../models/models_0");
const protocol_http_1 = require("@smithy/protocol-http");
const smithy_client_1 = require("@smithy/smithy-client");
const se_AutocompleteCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/autocomplete";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_AutocompleteFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'PostalCodeMode': [],
        'Query': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_AutocompleteCommand = se_AutocompleteCommand;
const se_GeocodeCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/geocode";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => (0, smithy_client_1._json)(_),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
        'QueryComponents': _ => (0, smithy_client_1._json)(_),
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_GeocodeCommand = se_GeocodeCommand;
const se_GetPlaceCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/place/{PlaceId}";
    resolvedPath = (0, smithy_client_1.resolvedPath)(resolvedPath, input, 'PlaceId', () => input.PlaceId, '{PlaceId}', false);
    const query = (0, smithy_client_1.map)({
        "additional-features": [() => input.AdditionalFeatures !== void 0, () => ((input.AdditionalFeatures || []).map(_entry => _entry))],
        "language": [, input.Language],
        "political-view": [, input.PoliticalView],
        "intended-use": [, input.IntendedUse],
        "key": [, input.Key],
    });
    let body;
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "GET",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_GetPlaceCommand = se_GetPlaceCommand;
const se_ReverseGeocodeCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/reverse-geocode";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'Filter': _ => (0, smithy_client_1._json)(_),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'QueryPosition': _ => se_Position(_, context),
        'QueryRadius': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_ReverseGeocodeCommand = se_ReverseGeocodeCommand;
const se_SearchNearbyCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/search-nearby";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'Filter': _ => se_SearchNearbyFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'QueryPosition': _ => se_Position(_, context),
        'QueryRadius': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_SearchNearbyCommand = se_SearchNearbyCommand;
const se_SearchTextCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/search-text";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_SearchTextFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
        'QueryId': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_SearchTextCommand = se_SearchTextCommand;
const se_SuggestCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = (0, smithy_client_1.map)({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/suggest";
    const query = (0, smithy_client_1.map)({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify((0, smithy_client_1.take)(input, {
        'AdditionalFeatures': _ => (0, smithy_client_1._json)(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_SuggestFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxQueryRefinements': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!(0, protocol_http_1.isValidHostname)(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new protocol_http_1.HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
exports.se_SuggestCommand = se_SuggestCommand;
const de_AutocompleteCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_AutocompleteCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'ResultItems': smithy_client_1._json,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_AutocompleteCommand = de_AutocompleteCommand;
const de_AutocompleteCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_GeocodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_GeocodeCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'ResultItems': _ => de_GeocodeResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GeocodeCommand = de_GeocodeCommand;
const de_GeocodeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_GetPlaceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_GetPlaceCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'AccessPoints': _ => de_AccessPointList(_, context),
        'AccessRestrictions': smithy_client_1._json,
        'Address': smithy_client_1._json,
        'AddressNumberCorrected': smithy_client_1.expectBoolean,
        'BusinessChains': smithy_client_1._json,
        'Categories': smithy_client_1._json,
        'Contacts': smithy_client_1._json,
        'FoodTypes': smithy_client_1._json,
        'MapView': _ => de_BoundingBox(_, context),
        'OpeningHours': smithy_client_1._json,
        'Phonemes': smithy_client_1._json,
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': _ => de_Position(_, context),
        'PostalCodeDetails': smithy_client_1._json,
        'TimeZone': smithy_client_1._json,
        'Title': smithy_client_1.expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_GetPlaceCommand = de_GetPlaceCommand;
const de_GetPlaceCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_ReverseGeocodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_ReverseGeocodeCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'ResultItems': _ => de_ReverseGeocodeResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_ReverseGeocodeCommand = de_ReverseGeocodeCommand;
const de_ReverseGeocodeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_SearchNearbyCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SearchNearbyCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'ResultItems': _ => de_SearchNearbyResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SearchNearbyCommand = de_SearchNearbyCommand;
const de_SearchNearbyCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_SearchTextCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SearchTextCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'ResultItems': _ => de_SearchTextResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SearchTextCommand = de_SearchTextCommand;
const de_SearchTextCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const de_SuggestCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SuggestCommandError(output, context);
    }
    const contents = (0, smithy_client_1.map)({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = (0, smithy_client_1.expectNonNull)(((0, smithy_client_1.expectObject)(await parseBody(output.body, context))), "body");
    const doc = (0, smithy_client_1.take)(data, {
        'QueryRefinements': smithy_client_1._json,
        'ResultItems': _ => de_SuggestResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
exports.de_SuggestCommand = de_SuggestCommand;
const de_SuggestCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = (0, smithy_client_1.withBaseException)(GeoPlacesServiceException_1.GeoPlacesServiceException);
const de_AccessDeniedExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'Message': [, smithy_client_1.expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.AccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'Message': [, smithy_client_1.expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ThrottlingExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'Message': [, smithy_client_1.expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ThrottlingException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const de_ValidationExceptionRes = async (parsedOutput, context) => {
    const contents = (0, smithy_client_1.map)({});
    const data = parsedOutput.body;
    const doc = (0, smithy_client_1.take)(data, {
        'FieldList': [, _ => de_ValidationExceptionFieldList(_, context), `fieldList`],
        'Message': [, smithy_client_1.expectString, `message`],
        'Reason': [, smithy_client_1.expectString, `reason`],
    });
    Object.assign(contents, doc);
    const exception = new models_0_1.ValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return (0, smithy_client_1.decorateServiceException)(exception, parsedOutput.body);
};
const se_AutocompleteFilter = (input, context) => {
    return (0, smithy_client_1.take)(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': smithy_client_1._json,
        'IncludePlaceTypes': smithy_client_1._json,
    });
};
const se_FilterCircle = (input, context) => {
    return (0, smithy_client_1.take)(input, {
        'Center': _ => se_Position(_, context),
        'Radius': [],
    });
};
const se_SearchNearbyFilter = (input, context) => {
    return (0, smithy_client_1.take)(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'ExcludeBusinessChains': smithy_client_1._json,
        'ExcludeCategories': smithy_client_1._json,
        'ExcludeFoodTypes': smithy_client_1._json,
        'IncludeBusinessChains': smithy_client_1._json,
        'IncludeCategories': smithy_client_1._json,
        'IncludeCountries': smithy_client_1._json,
        'IncludeFoodTypes': smithy_client_1._json,
    });
};
const se_SearchTextFilter = (input, context) => {
    return (0, smithy_client_1.take)(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': smithy_client_1._json,
    });
};
const se_SuggestFilter = (input, context) => {
    return (0, smithy_client_1.take)(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': smithy_client_1._json,
    });
};
const se_BoundingBox = (input, context) => {
    return input.filter((e) => e != null).map(entry => {
        return (0, smithy_client_1.serializeFloat)(entry);
    });
};
const se_Position = (input, context) => {
    return input.filter((e) => e != null).map(entry => {
        return (0, smithy_client_1.serializeFloat)(entry);
    });
};
const de_ValidationExceptionField = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'Message': [, smithy_client_1.expectString, `message`],
        'Name': [, smithy_client_1.expectString, `name`],
    });
};
const de_ValidationExceptionFieldList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_ValidationExceptionField(entry, context);
    });
    return retVal;
};
const de_AccessPoint = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'Position': (_) => de_Position(_, context),
    });
};
const de_AccessPointList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_AccessPoint(entry, context);
    });
    return retVal;
};
const de_AddressComponentMatchScores = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AddressNumber': smithy_client_1.limitedParseDouble,
        'Block': smithy_client_1.limitedParseDouble,
        'Building': smithy_client_1.limitedParseDouble,
        'Country': smithy_client_1.limitedParseDouble,
        'District': smithy_client_1.limitedParseDouble,
        'Intersection': (_) => de_MatchScoreList(_, context),
        'Locality': smithy_client_1.limitedParseDouble,
        'PostalCode': smithy_client_1.limitedParseDouble,
        'Region': smithy_client_1.limitedParseDouble,
        'SubBlock': smithy_client_1.limitedParseDouble,
        'SubDistrict': smithy_client_1.limitedParseDouble,
        'SubRegion': smithy_client_1.limitedParseDouble,
    });
};
const de_ComponentMatchScores = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'Address': (_) => de_AddressComponentMatchScores(_, context),
        'Title': smithy_client_1.limitedParseDouble,
    });
};
const de_GeocodeResultItem = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'Address': smithy_client_1._json,
        'AddressNumberCorrected': smithy_client_1.expectBoolean,
        'Categories': smithy_client_1._json,
        'Distance': smithy_client_1.expectLong,
        'FoodTypes': smithy_client_1._json,
        'MapView': (_) => de_BoundingBox(_, context),
        'MatchScores': (_) => de_MatchScoreDetails(_, context),
        'ParsedQuery': smithy_client_1._json,
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': (_) => de_Position(_, context),
        'PostalCodeDetails': smithy_client_1._json,
        'TimeZone': smithy_client_1._json,
        'Title': smithy_client_1.expectString,
    });
};
const de_GeocodeResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_GeocodeResultItem(entry, context);
    });
    return retVal;
};
const de_MatchScoreDetails = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'Components': (_) => de_ComponentMatchScores(_, context),
        'Overall': smithy_client_1.limitedParseDouble,
    });
};
const de_MatchScoreList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return (0, smithy_client_1.limitedParseDouble)(entry);
    });
    return retVal;
};
const de_ReverseGeocodeResultItem = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'Address': smithy_client_1._json,
        'AddressNumberCorrected': smithy_client_1.expectBoolean,
        'Categories': smithy_client_1._json,
        'Distance': smithy_client_1.expectLong,
        'FoodTypes': smithy_client_1._json,
        'MapView': (_) => de_BoundingBox(_, context),
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': (_) => de_Position(_, context),
        'PostalCodeDetails': smithy_client_1._json,
        'TimeZone': smithy_client_1._json,
        'Title': smithy_client_1.expectString,
    });
};
const de_ReverseGeocodeResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_ReverseGeocodeResultItem(entry, context);
    });
    return retVal;
};
const de_SearchNearbyResultItem = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': smithy_client_1._json,
        'Address': smithy_client_1._json,
        'AddressNumberCorrected': smithy_client_1.expectBoolean,
        'BusinessChains': smithy_client_1._json,
        'Categories': smithy_client_1._json,
        'Contacts': smithy_client_1._json,
        'Distance': smithy_client_1.expectLong,
        'FoodTypes': smithy_client_1._json,
        'MapView': (_) => de_BoundingBox(_, context),
        'OpeningHours': smithy_client_1._json,
        'Phonemes': smithy_client_1._json,
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': smithy_client_1._json,
        'Title': smithy_client_1.expectString,
    });
};
const de_SearchNearbyResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SearchNearbyResultItem(entry, context);
    });
    return retVal;
};
const de_SearchTextResultItem = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': smithy_client_1._json,
        'Address': smithy_client_1._json,
        'AddressNumberCorrected': smithy_client_1.expectBoolean,
        'BusinessChains': smithy_client_1._json,
        'Categories': smithy_client_1._json,
        'Contacts': smithy_client_1._json,
        'Distance': smithy_client_1.expectLong,
        'FoodTypes': smithy_client_1._json,
        'MapView': (_) => de_BoundingBox(_, context),
        'OpeningHours': smithy_client_1._json,
        'Phonemes': smithy_client_1._json,
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': smithy_client_1._json,
        'Title': smithy_client_1.expectString,
    });
};
const de_SearchTextResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SearchTextResultItem(entry, context);
    });
    return retVal;
};
const de_SuggestPlaceResult = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': smithy_client_1._json,
        'Address': smithy_client_1._json,
        'BusinessChains': smithy_client_1._json,
        'Categories': smithy_client_1._json,
        'Distance': smithy_client_1.expectLong,
        'FoodTypes': smithy_client_1._json,
        'MapView': (_) => de_BoundingBox(_, context),
        'Phonemes': smithy_client_1._json,
        'PlaceId': smithy_client_1.expectString,
        'PlaceType': smithy_client_1.expectString,
        'PoliticalView': smithy_client_1.expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': smithy_client_1._json,
    });
};
const de_SuggestResultItem = (output, context) => {
    return (0, smithy_client_1.take)(output, {
        'Highlights': smithy_client_1._json,
        'Place': (_) => de_SuggestPlaceResult(_, context),
        'Query': smithy_client_1._json,
        'SuggestResultItemType': smithy_client_1.expectString,
        'Title': smithy_client_1.expectString,
    });
};
const de_SuggestResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SuggestResultItem(entry, context);
    });
    return retVal;
};
const de_BoundingBox = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return (0, smithy_client_1.limitedParseDouble)(entry);
    });
    return retVal;
};
const de_Position = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return (0, smithy_client_1.limitedParseDouble)(entry);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => (0, smithy_client_1.collectBody)(streamBody, context).then(body => context.utf8Encoder(body));
const isSerializableHeaderValue = (value) => value !== undefined &&
    value !== null &&
    value !== "" &&
    (!Object.getOwnPropertyNames(value).includes("length") ||
        value.length != 0) &&
    (!Object.getOwnPropertyNames(value).includes("size") || value.size != 0);
const parseBody = (streamBody, context) => collectBodyString(streamBody, context).then(encoded => {
    if (encoded.length) {
        return JSON.parse(encoded);
    }
    return {};
});
const parseErrorBody = async (errorBody, context) => {
    const value = await parseBody(errorBody, context);
    value.message = value.message ?? value.Message;
    return value;
};
const loadRestJsonErrorCode = (output, data) => {
    const findKey = (object, key) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());
    const sanitizeErrorCode = (rawValue) => {
        let cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        if (cleanValue.indexOf("#") >= 0) {
            cleanValue = cleanValue.split("#")[1];
        }
        return cleanValue;
    };
    const headerKey = findKey(output.headers, "x-amzn-errortype");
    if (headerKey !== undefined) {
        return sanitizeErrorCode(output.headers[headerKey]);
    }
    if (data.code !== undefined) {
        return sanitizeErrorCode(data.code);
    }
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};
