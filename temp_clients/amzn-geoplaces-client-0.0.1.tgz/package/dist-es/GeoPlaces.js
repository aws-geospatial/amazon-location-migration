import { GeoPlacesClient, } from "./GeoPlacesClient";
import { AutocompleteCommand, } from "./commands/AutocompleteCommand";
import { GeocodeCommand, } from "./commands/GeocodeCommand";
import { GetPlaceCommand, } from "./commands/GetPlaceCommand";
import { ReverseGeocodeCommand, } from "./commands/ReverseGeocodeCommand";
import { SearchNearbyCommand, } from "./commands/SearchNearbyCommand";
import { SearchTextCommand, } from "./commands/SearchTextCommand";
import { SuggestCommand, } from "./commands/SuggestCommand";
import { createAggregatedClient } from "@smithy/smithy-client";
const commands = {
    AutocompleteCommand,
    GeocodeCommand,
    GetPlaceCommand,
    ReverseGeocodeCommand,
    SearchNearbyCommand,
    SearchTextCommand,
    SuggestCommand,
};
export class GeoPlaces extends GeoPlacesClient {
}
createAggregatedClient(commands, GeoPlaces);
