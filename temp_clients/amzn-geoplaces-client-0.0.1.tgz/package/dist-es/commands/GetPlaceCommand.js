import { GetPlaceRequestFilterSensitiveLog, GetPlaceResponseFilterSensitiveLog, } from "../models/models_0";
import { de_GetPlaceCommand, se_GetPlaceCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { SMITHY_CONTEXT_KEY, } from "@smithy/types";
export { $Command };
export class GetPlaceCommand extends $Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "GeoPlacesClient";
        const commandName = "GetPlaceCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: GetPlaceRequestFilterSensitiveLog,
            outputFilterSensitiveLog: GetPlaceResponseFilterSensitiveLog,
            [SMITHY_CONTEXT_KEY]: {
                service: "PlacesService",
                operation: "GetPlace",
            },
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return se_GetPlaceCommand(input, context);
    }
    deserialize(output, context) {
        return de_GetPlaceCommand(output, context);
    }
}
