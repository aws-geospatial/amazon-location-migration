import { ReverseGeocodeRequestFilterSensitiveLog, ReverseGeocodeResponseFilterSensitiveLog, } from "../models/models_0";
import { de_ReverseGeocodeCommand, se_ReverseGeocodeCommand, } from "../protocols/Aws_restJson1";
import { getSerdePlugin } from "@smithy/middleware-serde";
import { Command as $Command } from "@smithy/smithy-client";
import { SMITHY_CONTEXT_KEY, } from "@smithy/types";
export { $Command };
export class ReverseGeocodeCommand extends $Command {
    constructor(input) {
        super();
        this.input = input;
    }
    resolveMiddleware(clientStack, configuration, options) {
        this.middlewareStack.use(getSerdePlugin(configuration, this.serialize, this.deserialize));
        const stack = clientStack.concat(this.middlewareStack);
        const { logger } = configuration;
        const clientName = "GeoPlacesClient";
        const commandName = "ReverseGeocodeCommand";
        const handlerExecutionContext = {
            logger,
            clientName,
            commandName,
            inputFilterSensitiveLog: ReverseGeocodeRequestFilterSensitiveLog,
            outputFilterSensitiveLog: ReverseGeocodeResponseFilterSensitiveLog,
            [SMITHY_CONTEXT_KEY]: {
                service: "PlacesService",
                operation: "ReverseGeocode",
            },
        };
        const { requestHandler } = configuration;
        return stack.resolve((request) => requestHandler.handle(request.request, options || {}), handlerExecutionContext);
    }
    serialize(input, context) {
        return se_ReverseGeocodeCommand(input, context);
    }
    deserialize(output, context) {
        return de_ReverseGeocodeCommand(output, context);
    }
}
