import { GeoPlacesServiceException as __BaseException } from "./GeoPlacesServiceException";
import { SENSITIVE_STRING, } from "@smithy/smithy-client";
export class AccessDeniedException extends __BaseException {
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts
        });
        this.name = "AccessDeniedException";
        this.$fault = "client";
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
export class InternalServerException extends __BaseException {
    constructor(opts) {
        super({
            name: "InternalServerException",
            $fault: "server",
            ...opts
        });
        this.name = "InternalServerException";
        this.$fault = "server";
        this.$retryable = {};
        Object.setPrototypeOf(this, InternalServerException.prototype);
        this.Message = opts.Message;
    }
}
export class ThrottlingException extends __BaseException {
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts
        });
        this.name = "ThrottlingException";
        this.$fault = "client";
        this.$retryable = {};
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
    }
}
export class ValidationException extends __BaseException {
    constructor(opts) {
        super({
            name: "ValidationException",
            $fault: "client",
            ...opts
        });
        this.name = "ValidationException";
        this.$fault = "client";
        Object.setPrototypeOf(this, ValidationException.prototype);
        this.Message = opts.Message;
        this.Reason = opts.Reason;
        this.FieldList = opts.FieldList;
    }
}
export const AccessPointFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
});
export const FilterCircleFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Center && { Center: SENSITIVE_STRING
    }),
});
export const AutocompleteFilterFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.BoundingBox && { BoundingBox: SENSITIVE_STRING
    }),
    ...(obj.Circle && { Circle: SENSITIVE_STRING
    }),
});
export const AutocompleteRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: SENSITIVE_STRING
    }),
    ...(obj.Filter && { Filter: AutocompleteFilterFilterSensitiveLog(obj.Filter)
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const GeocodeQueryComponentsFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Country && { Country: SENSITIVE_STRING
    }),
    ...(obj.Region && { Region: SENSITIVE_STRING
    }),
    ...(obj.SubRegion && { SubRegion: SENSITIVE_STRING
    }),
    ...(obj.Locality && { Locality: SENSITIVE_STRING
    }),
    ...(obj.District && { District: SENSITIVE_STRING
    }),
    ...(obj.Street && { Street: SENSITIVE_STRING
    }),
    ...(obj.AddressNumber && { AddressNumber: SENSITIVE_STRING
    }),
    ...(obj.PostalCode && { PostalCode: SENSITIVE_STRING
    }),
});
export const GeocodeRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: SENSITIVE_STRING
    }),
    ...(obj.QueryComponents && { QueryComponents: GeocodeQueryComponentsFilterSensitiveLog(obj.QueryComponents)
    }),
    ...(obj.BiasPosition && { BiasPosition: SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const GeocodeResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const GeocodeResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => GeocodeResultItemFilterSensitiveLog(item))
    }),
});
export const GetPlaceRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.PlaceId && { PlaceId: SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const GetPlaceResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const ReverseGeocodeRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.QueryPosition && { QueryPosition: SENSITIVE_STRING
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const ReverseGeocodeResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const ReverseGeocodeResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => ReverseGeocodeResultItemFilterSensitiveLog(item))
    }),
});
export const SearchNearbyFilterFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.BoundingBox && { BoundingBox: SENSITIVE_STRING
    }),
});
export const SearchNearbyRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.QueryPosition && { QueryPosition: SENSITIVE_STRING
    }),
    ...(obj.Filter && { Filter: SearchNearbyFilterFilterSensitiveLog(obj.Filter)
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const SearchNearbyResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const SearchNearbyResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => SearchNearbyResultItemFilterSensitiveLog(item))
    }),
});
export const SearchTextFilterFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.BoundingBox && { BoundingBox: SENSITIVE_STRING
    }),
    ...(obj.Circle && { Circle: SENSITIVE_STRING
    }),
});
export const SearchTextRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: SENSITIVE_STRING
    }),
    ...(obj.QueryId && { QueryId: SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: SENSITIVE_STRING
    }),
    ...(obj.Filter && { Filter: SearchTextFilterFilterSensitiveLog(obj.Filter)
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const SearchTextResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const SearchTextResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => SearchTextResultItemFilterSensitiveLog(item))
    }),
});
export const SuggestFilterFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.BoundingBox && { BoundingBox: SENSITIVE_STRING
    }),
    ...(obj.Circle && { Circle: SENSITIVE_STRING
    }),
});
export const SuggestRequestFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Query && { Query: SENSITIVE_STRING
    }),
    ...(obj.BiasPosition && { BiasPosition: SENSITIVE_STRING
    }),
    ...(obj.Filter && { Filter: SuggestFilterFilterSensitiveLog(obj.Filter)
    }),
    ...(obj.Key && { Key: SENSITIVE_STRING
    }),
    ...(obj.KeyHeader && { KeyHeader: SENSITIVE_STRING
    }),
});
export const SuggestPlaceResultFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Position && { Position: SENSITIVE_STRING
    }),
    ...(obj.MapView && { MapView: SENSITIVE_STRING
    }),
    ...(obj.AccessPoints && { AccessPoints: obj.AccessPoints.map(item => AccessPointFilterSensitiveLog(item))
    }),
});
export const SuggestResultItemFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.Place && { Place: SuggestPlaceResultFilterSensitiveLog(obj.Place)
    }),
});
export const SuggestResponseFilterSensitiveLog = (obj) => ({
    ...obj,
    ...(obj.ResultItems && { ResultItems: obj.ResultItems.map(item => SuggestResultItemFilterSensitiveLog(item))
    }),
});
