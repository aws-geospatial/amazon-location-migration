import { GeoPlacesServiceException as __BaseException } from "../models/GeoPlacesServiceException";
import { AccessDeniedException, InternalServerException, ThrottlingException, ValidationException, } from "../models/models_0";
import { HttpRequest as __HttpRequest, isValidHostname as __isValidHostname, } from "@smithy/protocol-http";
import { decorateServiceException as __decorateServiceException, expectBoolean as __expectBoolean, expectLong as __expectLong, expectNonNull as __expectNonNull, expectObject as __expectObject, expectString as __expectString, limitedParseDouble as __limitedParseDouble, resolvedPath as __resolvedPath, serializeFloat as __serializeFloat, _json, collectBody, map, take, withBaseException, } from "@smithy/smithy-client";
export const se_AutocompleteCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/autocomplete";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_AutocompleteFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'PostalCodeMode': [],
        'Query': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_GeocodeCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/geocode";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => _json(_),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
        'QueryComponents': _ => _json(_),
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_GetPlaceCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/place/{PlaceId}";
    resolvedPath = __resolvedPath(resolvedPath, input, 'PlaceId', () => input.PlaceId, '{PlaceId}', false);
    const query = map({
        "additional-features": [() => input.AdditionalFeatures !== void 0, () => ((input.AdditionalFeatures || []).map(_entry => _entry))],
        "language": [, input.Language],
        "political-view": [, input.PoliticalView],
        "intended-use": [, input.IntendedUse],
        "key": [, input.Key],
    });
    let body;
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "GET",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_ReverseGeocodeCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/reverse-geocode";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'Filter': _ => _json(_),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'QueryPosition': _ => se_Position(_, context),
        'QueryRadius': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_SearchNearbyCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/search-nearby";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'Filter': _ => se_SearchNearbyFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'QueryPosition': _ => se_Position(_, context),
        'QueryRadius': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_SearchTextCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/search-text";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_SearchTextFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
        'QueryId': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const se_SuggestCommand = async (input, context) => {
    const { hostname, protocol = "https", port, path: basePath } = await context.endpoint();
    const headers = map({}, isSerializableHeaderValue, {
        'content-type': 'application/json',
        'api-key': input.KeyHeader,
    });
    let resolvedPath = `${basePath?.endsWith('/') ? basePath.slice(0, -1) : (basePath || '')}` + "/suggest";
    const query = map({
        "key": [, input.Key],
    });
    let body;
    body = JSON.stringify(take(input, {
        'AdditionalFeatures': _ => _json(_),
        'BiasPosition': _ => se_Position(_, context),
        'Filter': _ => se_SuggestFilter(_, context),
        'IntendedUse': [],
        'Language': [],
        'MaxQueryRefinements': [],
        'MaxResults': [],
        'PoliticalView': [],
        'Query': [],
    }));
    let { hostname: resolvedHostname } = await context.endpoint();
    if (context.disableHostPrefix !== true) {
        resolvedHostname = "places." + resolvedHostname;
        if (!__isValidHostname(resolvedHostname)) {
            throw new Error("ValidationError: prefixed hostname must be hostname compatible.");
        }
    }
    return new __HttpRequest({
        protocol,
        hostname: resolvedHostname,
        port,
        method: "POST",
        headers,
        path: resolvedPath,
        query,
        body,
    });
};
export const de_AutocompleteCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_AutocompleteCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'ResultItems': _json,
    });
    Object.assign(contents, doc);
    return contents;
};
const de_AutocompleteCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_GeocodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_GeocodeCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'ResultItems': _ => de_GeocodeResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
const de_GeocodeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_GetPlaceCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_GetPlaceCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'AccessPoints': _ => de_AccessPointList(_, context),
        'AccessRestrictions': _json,
        'Address': _json,
        'AddressNumberCorrected': __expectBoolean,
        'BusinessChains': _json,
        'Categories': _json,
        'Contacts': _json,
        'FoodTypes': _json,
        'MapView': _ => de_BoundingBox(_, context),
        'OpeningHours': _json,
        'Phonemes': _json,
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': _ => de_Position(_, context),
        'PostalCodeDetails': _json,
        'TimeZone': _json,
        'Title': __expectString,
    });
    Object.assign(contents, doc);
    return contents;
};
const de_GetPlaceCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_ReverseGeocodeCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_ReverseGeocodeCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'ResultItems': _ => de_ReverseGeocodeResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
const de_ReverseGeocodeCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_SearchNearbyCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SearchNearbyCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'ResultItems': _ => de_SearchNearbyResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
const de_SearchNearbyCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_SearchTextCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SearchTextCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'ResultItems': _ => de_SearchTextResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
const de_SearchTextCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
export const de_SuggestCommand = async (output, context) => {
    if (output.statusCode !== 200 && output.statusCode >= 300) {
        return de_SuggestCommandError(output, context);
    }
    const contents = map({
        $metadata: deserializeMetadata(output),
        PricingBucket: [, output.headers['x-amz-geo-pricing-bucket']],
    });
    const data = __expectNonNull((__expectObject(await parseBody(output.body, context))), "body");
    const doc = take(data, {
        'QueryRefinements': _json,
        'ResultItems': _ => de_SuggestResultItemList(_, context),
    });
    Object.assign(contents, doc);
    return contents;
};
const de_SuggestCommandError = async (output, context) => {
    const parsedOutput = {
        ...output,
        body: await parseErrorBody(output.body, context)
    };
    const errorCode = loadRestJsonErrorCode(output, parsedOutput.body);
    switch (errorCode) {
        case "AccessDeniedException":
        case "com.amazonaws.services.waypoint.exceptions#AccessDeniedException":
            throw await de_AccessDeniedExceptionRes(parsedOutput, context);
        case "InternalServerException":
        case "com.amazonaws.services.waypoint.exceptions#InternalServerException":
            throw await de_InternalServerExceptionRes(parsedOutput, context);
        case "ThrottlingException":
        case "com.amazonaws.services.waypoint.exceptions#ThrottlingException":
            throw await de_ThrottlingExceptionRes(parsedOutput, context);
        case "ValidationException":
        case "com.amazonaws.services.waypoint.exceptions#ValidationException":
            throw await de_ValidationExceptionRes(parsedOutput, context);
        default:
            const parsedBody = parsedOutput.body;
            return throwDefaultError({
                output,
                parsedBody,
                errorCode
            });
    }
};
const throwDefaultError = withBaseException(__BaseException);
const de_AccessDeniedExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'Message': [, __expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new AccessDeniedException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_InternalServerExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'Message': [, __expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new InternalServerException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ThrottlingExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'Message': [, __expectString, `message`],
    });
    Object.assign(contents, doc);
    const exception = new ThrottlingException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const de_ValidationExceptionRes = async (parsedOutput, context) => {
    const contents = map({});
    const data = parsedOutput.body;
    const doc = take(data, {
        'FieldList': [, _ => de_ValidationExceptionFieldList(_, context), `fieldList`],
        'Message': [, __expectString, `message`],
        'Reason': [, __expectString, `reason`],
    });
    Object.assign(contents, doc);
    const exception = new ValidationException({
        $metadata: deserializeMetadata(parsedOutput),
        ...contents
    });
    return __decorateServiceException(exception, parsedOutput.body);
};
const se_AutocompleteFilter = (input, context) => {
    return take(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': _json,
        'IncludePlaceTypes': _json,
    });
};
const se_FilterCircle = (input, context) => {
    return take(input, {
        'Center': _ => se_Position(_, context),
        'Radius': [],
    });
};
const se_SearchNearbyFilter = (input, context) => {
    return take(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'ExcludeBusinessChains': _json,
        'ExcludeCategories': _json,
        'ExcludeFoodTypes': _json,
        'IncludeBusinessChains': _json,
        'IncludeCategories': _json,
        'IncludeCountries': _json,
        'IncludeFoodTypes': _json,
    });
};
const se_SearchTextFilter = (input, context) => {
    return take(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': _json,
    });
};
const se_SuggestFilter = (input, context) => {
    return take(input, {
        'BoundingBox': _ => se_BoundingBox(_, context),
        'Circle': _ => se_FilterCircle(_, context),
        'IncludeCountries': _json,
    });
};
const se_BoundingBox = (input, context) => {
    return input.filter((e) => e != null).map(entry => {
        return __serializeFloat(entry);
    });
};
const se_Position = (input, context) => {
    return input.filter((e) => e != null).map(entry => {
        return __serializeFloat(entry);
    });
};
const de_ValidationExceptionField = (output, context) => {
    return take(output, {
        'Message': [, __expectString, `message`],
        'Name': [, __expectString, `name`],
    });
};
const de_ValidationExceptionFieldList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_ValidationExceptionField(entry, context);
    });
    return retVal;
};
const de_AccessPoint = (output, context) => {
    return take(output, {
        'Position': (_) => de_Position(_, context),
    });
};
const de_AccessPointList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_AccessPoint(entry, context);
    });
    return retVal;
};
const de_AddressComponentMatchScores = (output, context) => {
    return take(output, {
        'AddressNumber': __limitedParseDouble,
        'Block': __limitedParseDouble,
        'Building': __limitedParseDouble,
        'Country': __limitedParseDouble,
        'District': __limitedParseDouble,
        'Intersection': (_) => de_MatchScoreList(_, context),
        'Locality': __limitedParseDouble,
        'PostalCode': __limitedParseDouble,
        'Region': __limitedParseDouble,
        'SubBlock': __limitedParseDouble,
        'SubDistrict': __limitedParseDouble,
        'SubRegion': __limitedParseDouble,
    });
};
const de_ComponentMatchScores = (output, context) => {
    return take(output, {
        'Address': (_) => de_AddressComponentMatchScores(_, context),
        'Title': __limitedParseDouble,
    });
};
const de_GeocodeResultItem = (output, context) => {
    return take(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'Address': _json,
        'AddressNumberCorrected': __expectBoolean,
        'Categories': _json,
        'Distance': __expectLong,
        'FoodTypes': _json,
        'MapView': (_) => de_BoundingBox(_, context),
        'MatchScores': (_) => de_MatchScoreDetails(_, context),
        'ParsedQuery': _json,
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': (_) => de_Position(_, context),
        'PostalCodeDetails': _json,
        'TimeZone': _json,
        'Title': __expectString,
    });
};
const de_GeocodeResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_GeocodeResultItem(entry, context);
    });
    return retVal;
};
const de_MatchScoreDetails = (output, context) => {
    return take(output, {
        'Components': (_) => de_ComponentMatchScores(_, context),
        'Overall': __limitedParseDouble,
    });
};
const de_MatchScoreList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return __limitedParseDouble(entry);
    });
    return retVal;
};
const de_ReverseGeocodeResultItem = (output, context) => {
    return take(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'Address': _json,
        'AddressNumberCorrected': __expectBoolean,
        'Categories': _json,
        'Distance': __expectLong,
        'FoodTypes': _json,
        'MapView': (_) => de_BoundingBox(_, context),
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': (_) => de_Position(_, context),
        'PostalCodeDetails': _json,
        'TimeZone': _json,
        'Title': __expectString,
    });
};
const de_ReverseGeocodeResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_ReverseGeocodeResultItem(entry, context);
    });
    return retVal;
};
const de_SearchNearbyResultItem = (output, context) => {
    return take(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': _json,
        'Address': _json,
        'AddressNumberCorrected': __expectBoolean,
        'BusinessChains': _json,
        'Categories': _json,
        'Contacts': _json,
        'Distance': __expectLong,
        'FoodTypes': _json,
        'MapView': (_) => de_BoundingBox(_, context),
        'OpeningHours': _json,
        'Phonemes': _json,
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': _json,
        'Title': __expectString,
    });
};
const de_SearchNearbyResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SearchNearbyResultItem(entry, context);
    });
    return retVal;
};
const de_SearchTextResultItem = (output, context) => {
    return take(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': _json,
        'Address': _json,
        'AddressNumberCorrected': __expectBoolean,
        'BusinessChains': _json,
        'Categories': _json,
        'Contacts': _json,
        'Distance': __expectLong,
        'FoodTypes': _json,
        'MapView': (_) => de_BoundingBox(_, context),
        'OpeningHours': _json,
        'Phonemes': _json,
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': _json,
        'Title': __expectString,
    });
};
const de_SearchTextResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SearchTextResultItem(entry, context);
    });
    return retVal;
};
const de_SuggestPlaceResult = (output, context) => {
    return take(output, {
        'AccessPoints': (_) => de_AccessPointList(_, context),
        'AccessRestrictions': _json,
        'Address': _json,
        'BusinessChains': _json,
        'Categories': _json,
        'Distance': __expectLong,
        'FoodTypes': _json,
        'MapView': (_) => de_BoundingBox(_, context),
        'Phonemes': _json,
        'PlaceId': __expectString,
        'PlaceType': __expectString,
        'PoliticalView': __expectString,
        'Position': (_) => de_Position(_, context),
        'TimeZone': _json,
    });
};
const de_SuggestResultItem = (output, context) => {
    return take(output, {
        'Highlights': _json,
        'Place': (_) => de_SuggestPlaceResult(_, context),
        'Query': _json,
        'SuggestResultItemType': __expectString,
        'Title': __expectString,
    });
};
const de_SuggestResultItemList = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return de_SuggestResultItem(entry, context);
    });
    return retVal;
};
const de_BoundingBox = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return __limitedParseDouble(entry);
    });
    return retVal;
};
const de_Position = (output, context) => {
    const retVal = (output || []).filter((e) => e != null).map((entry) => {
        return __limitedParseDouble(entry);
    });
    return retVal;
};
const deserializeMetadata = (output) => ({
    httpStatusCode: output.statusCode,
    requestId: output.headers["x-amzn-requestid"] ?? output.headers["x-amzn-request-id"] ?? output.headers["x-amz-request-id"],
    extendedRequestId: output.headers["x-amz-id-2"],
    cfId: output.headers["x-amz-cf-id"],
});
const collectBodyString = (streamBody, context) => collectBody(streamBody, context).then(body => context.utf8Encoder(body));
const isSerializableHeaderValue = (value) => value !== undefined &&
    value !== null &&
    value !== "" &&
    (!Object.getOwnPropertyNames(value).includes("length") ||
        value.length != 0) &&
    (!Object.getOwnPropertyNames(value).includes("size") || value.size != 0);
const parseBody = (streamBody, context) => collectBodyString(streamBody, context).then(encoded => {
    if (encoded.length) {
        return JSON.parse(encoded);
    }
    return {};
});
const parseErrorBody = async (errorBody, context) => {
    const value = await parseBody(errorBody, context);
    value.message = value.message ?? value.Message;
    return value;
};
const loadRestJsonErrorCode = (output, data) => {
    const findKey = (object, key) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());
    const sanitizeErrorCode = (rawValue) => {
        let cleanValue = rawValue;
        if (typeof cleanValue === "number") {
            cleanValue = cleanValue.toString();
        }
        if (cleanValue.indexOf(",") >= 0) {
            cleanValue = cleanValue.split(",")[0];
        }
        if (cleanValue.indexOf(":") >= 0) {
            cleanValue = cleanValue.split(":")[0];
        }
        if (cleanValue.indexOf("#") >= 0) {
            cleanValue = cleanValue.split("#")[1];
        }
        return cleanValue;
    };
    const headerKey = findKey(output.headers, "x-amzn-errortype");
    if (headerKey !== undefined) {
        return sanitizeErrorCode(output.headers[headerKey]);
    }
    if (data.code !== undefined) {
        return sanitizeErrorCode(data.code);
    }
    if (data["__type"] !== undefined) {
        return sanitizeErrorCode(data["__type"]);
    }
};
