import { GeoPlacesClient } from "./GeoPlacesClient";
import { AutocompleteCommandInput, AutocompleteCommandOutput } from "./commands/AutocompleteCommand";
import { GeocodeCommandInput, GeocodeCommandOutput } from "./commands/GeocodeCommand";
import { GetPlaceCommandInput, GetPlaceCommandOutput } from "./commands/GetPlaceCommand";
import { ReverseGeocodeCommandInput, ReverseGeocodeCommandOutput } from "./commands/ReverseGeocodeCommand";
import { SearchNearbyCommandInput, SearchNearbyCommandOutput } from "./commands/SearchNearbyCommand";
import { SearchTextCommandInput, SearchTextCommandOutput } from "./commands/SearchTextCommand";
import { SuggestCommandInput, SuggestCommandOutput } from "./commands/SuggestCommand";
import { HttpHandlerOptions as __HttpHandlerOptions } from "@smithy/types";
export interface GeoPlaces {
    /**
     * @see {@link AutocompleteCommand}
     */
    autocomplete(args: AutocompleteCommandInput, options?: __HttpHandlerOptions): Promise<AutocompleteCommandOutput>;
    autocomplete(args: AutocompleteCommandInput, cb: (err: any, data?: AutocompleteCommandOutput) => void): void;
    autocomplete(args: AutocompleteCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: AutocompleteCommandOutput) => void): void;
    /**
     * @see {@link GeocodeCommand}
     */
    geocode(args: GeocodeCommandInput, options?: __HttpHandlerOptions): Promise<GeocodeCommandOutput>;
    geocode(args: GeocodeCommandInput, cb: (err: any, data?: GeocodeCommandOutput) => void): void;
    geocode(args: GeocodeCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GeocodeCommandOutput) => void): void;
    /**
     * @see {@link GetPlaceCommand}
     */
    getPlace(args: GetPlaceCommandInput, options?: __HttpHandlerOptions): Promise<GetPlaceCommandOutput>;
    getPlace(args: GetPlaceCommandInput, cb: (err: any, data?: GetPlaceCommandOutput) => void): void;
    getPlace(args: GetPlaceCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: GetPlaceCommandOutput) => void): void;
    /**
     * @see {@link ReverseGeocodeCommand}
     */
    reverseGeocode(args: ReverseGeocodeCommandInput, options?: __HttpHandlerOptions): Promise<ReverseGeocodeCommandOutput>;
    reverseGeocode(args: ReverseGeocodeCommandInput, cb: (err: any, data?: ReverseGeocodeCommandOutput) => void): void;
    reverseGeocode(args: ReverseGeocodeCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: ReverseGeocodeCommandOutput) => void): void;
    /**
     * @see {@link SearchNearbyCommand}
     */
    searchNearby(args: SearchNearbyCommandInput, options?: __HttpHandlerOptions): Promise<SearchNearbyCommandOutput>;
    searchNearby(args: SearchNearbyCommandInput, cb: (err: any, data?: SearchNearbyCommandOutput) => void): void;
    searchNearby(args: SearchNearbyCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SearchNearbyCommandOutput) => void): void;
    /**
     * @see {@link SearchTextCommand}
     */
    searchText(args: SearchTextCommandInput, options?: __HttpHandlerOptions): Promise<SearchTextCommandOutput>;
    searchText(args: SearchTextCommandInput, cb: (err: any, data?: SearchTextCommandOutput) => void): void;
    searchText(args: SearchTextCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SearchTextCommandOutput) => void): void;
    /**
     * @see {@link SuggestCommand}
     */
    suggest(args: SuggestCommandInput, options?: __HttpHandlerOptions): Promise<SuggestCommandOutput>;
    suggest(args: SuggestCommandInput, cb: (err: any, data?: SuggestCommandOutput) => void): void;
    suggest(args: SuggestCommandInput, options: __HttpHandlerOptions, cb: (err: any, data?: SuggestCommandOutput) => void): void;
}
/**
 * @public
 */
export declare class GeoPlaces extends GeoPlacesClient implements GeoPlaces {
}
