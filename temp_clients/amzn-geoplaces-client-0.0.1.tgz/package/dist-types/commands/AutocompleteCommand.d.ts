import { GeoPlacesClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GeoPlacesClient";
import { AutocompleteRequest, AutocompleteResponse } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link AutocompleteCommand}.
 */
export interface AutocompleteCommandInput extends AutocompleteRequest {
}
/**
 * @public
 *
 * The output of {@link AutocompleteCommand}.
 */
export interface AutocompleteCommandOutput extends AutocompleteResponse, __MetadataBearer {
}
/**
 * @internal
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GeoPlacesClient, AutocompleteCommand } from "@amzn/geoplaces-client"; // ES Modules import
 * // const { GeoPlacesClient, AutocompleteCommand } = require("@amzn/geoplaces-client"); // CommonJS import
 * const client = new GeoPlacesClient(config);
 * const input = { // AutocompleteRequest
 *   Query: "STRING_VALUE", // required
 *   MaxResults: Number("int"),
 *   BiasPosition: [ // Position
 *     Number("double"),
 *   ],
 *   FilterBoundingBox: [ // BoundingBox
 *     Number("double"),
 *   ],
 *   FilterCircle: { // FilterCircle
 *     Center: [ // required
 *       Number("double"),
 *     ],
 *     Radius: Number("long"), // required
 *   },
 *   FilterCountries: [ // CountryCodeList
 *     "STRING_VALUE",
 *   ],
 *   FilterPlaceTypes: [ // PlaceTypeList
 *     "STRING_VALUE",
 *   ],
 *   PostalCodeMode: "STRING_VALUE",
 *   AdditionalFeatures: [ // AutocompleteAdditionalFeatureList
 *     "STRING_VALUE",
 *   ],
 *   Language: "STRING_VALUE",
 *   PoliticalView: "STRING_VALUE",
 *   IntendedUse: "STRING_VALUE",
 *   Key: "STRING_VALUE",
 *   KeyHeader: "STRING_VALUE",
 * };
 * const command = new AutocompleteCommand(input);
 * const response = await client.send(command);
 * // { // AutocompleteResponse
 * //   PricingTier: "STRING_VALUE", // required
 * //   ResultItems: [ // AutocompleteResultItemList
 * //     { // AutocompleteResultItem
 * //       PlaceId: "STRING_VALUE", // required
 * //       PlaceType: "STRING_VALUE", // required
 * //       Title: "STRING_VALUE", // required
 * //       Address: { // Address
 * //         Label: "STRING_VALUE",
 * //         Country: { // Country
 * //           Code2: "STRING_VALUE",
 * //           Code3: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Region: { // Region
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         SubRegion: { // SubRegion
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Locality: "STRING_VALUE",
 * //         District: "STRING_VALUE",
 * //         SubDistrict: "STRING_VALUE",
 * //         PostalCode: "STRING_VALUE",
 * //         Block: "STRING_VALUE",
 * //         SubBlock: "STRING_VALUE",
 * //         Intersection: [ // IntersectionList
 * //           "STRING_VALUE",
 * //         ],
 * //         Street: "STRING_VALUE",
 * //         StreetComponents: [ // StreetComponentsList
 * //           { // StreetComponents
 * //             BaseName: "STRING_VALUE",
 * //             Type: "STRING_VALUE",
 * //             TypePlacement: "STRING_VALUE",
 * //             TypeSeparator: "STRING_VALUE",
 * //             Prefix: "STRING_VALUE",
 * //             Suffix: "STRING_VALUE",
 * //             Direction: "STRING_VALUE",
 * //             Language: "STRING_VALUE",
 * //           },
 * //         ],
 * //         AddressNumber: "STRING_VALUE",
 * //         Building: "STRING_VALUE",
 * //       },
 * //       Distance: Number("long"),
 * //       Language: "STRING_VALUE",
 * //       PoliticalView: "STRING_VALUE",
 * //       Highlights: { // AutocompleteHighlights
 * //         Title: [ // HighlightList
 * //           { // Highlight
 * //             StartIndex: Number("int"),
 * //             EndIndex: Number("int"),
 * //           },
 * //         ],
 * //         Address: { // AutocompleteAddressHighlights
 * //           Label: [
 * //             {
 * //               StartIndex: Number("int"),
 * //               EndIndex: Number("int"),
 * //             },
 * //           ],
 * //           Country: { // CountryHighlights
 * //             Code: "<HighlightList>",
 * //             Name: "<HighlightList>",
 * //           },
 * //           Region: { // RegionHighlights
 * //             Code: "<HighlightList>",
 * //             Name: "<HighlightList>",
 * //           },
 * //           SubRegion: { // SubRegionHighlights
 * //             Code: "<HighlightList>",
 * //             Name: "<HighlightList>",
 * //           },
 * //           Locality: "<HighlightList>",
 * //           District: "<HighlightList>",
 * //           SubDistrict: "<HighlightList>",
 * //           Street: "<HighlightList>",
 * //           PostalCode: "<HighlightList>",
 * //           AddressNumber: "<HighlightList>",
 * //         },
 * //       },
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param AutocompleteCommandInput - {@link AutocompleteCommandInput}
 * @returns {@link AutocompleteCommandOutput}
 * @see {@link AutocompleteCommandInput} for command's `input` shape.
 * @see {@link AutocompleteCommandOutput} for command's `response` shape.
 * @see {@link GeoPlacesClientResolvedConfig | config} for GeoPlacesClient's `config` shape.
 *
 * @throws {@link ValidationException} (client fault)
 *
 * @throws {@link AccessDeniedException} (client fault)
 *
 * @throws {@link ThrottlingException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link GeoPlacesServiceException}
 * <p>Base exception class for all service exceptions from GeoPlaces service.</p>
 *
 */
export declare class AutocompleteCommand extends $Command<AutocompleteCommandInput, AutocompleteCommandOutput, GeoPlacesClientResolvedConfig> {
    readonly input: AutocompleteCommandInput;
    /**
     * @public
     */
    constructor(input: AutocompleteCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: GeoPlacesClientResolvedConfig, options?: __HttpHandlerOptions): Handler<AutocompleteCommandInput, AutocompleteCommandOutput>;
    /**
     * @internal
     */
    private serialize;
    /**
     * @internal
     */
    private deserialize;
}
