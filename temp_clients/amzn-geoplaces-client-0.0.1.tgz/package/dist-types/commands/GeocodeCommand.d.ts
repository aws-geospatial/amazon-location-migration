import { GeoPlacesClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GeoPlacesClient";
import { GeocodeRequest, GeocodeResponse } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link GeocodeCommand}.
 */
export interface GeocodeCommandInput extends GeocodeRequest {
}
/**
 * @public
 *
 * The output of {@link GeocodeCommand}.
 */
export interface GeocodeCommandOutput extends GeocodeResponse, __MetadataBearer {
}
/**
 * @internal
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GeoPlacesClient, GeocodeCommand } from "@amzn/geoplaces-client"; // ES Modules import
 * // const { GeoPlacesClient, GeocodeCommand } = require("@amzn/geoplaces-client"); // CommonJS import
 * const client = new GeoPlacesClient(config);
 * const input = { // GeocodeRequest
 *   Query: "STRING_VALUE",
 *   QueryComponents: { // GeocodeQueryComponents
 *     Country: "STRING_VALUE",
 *     Region: "STRING_VALUE",
 *     SubRegion: "STRING_VALUE",
 *     Locality: "STRING_VALUE",
 *     District: "STRING_VALUE",
 *     Street: "STRING_VALUE",
 *     AddressNumber: "STRING_VALUE",
 *     PostalCode: "STRING_VALUE",
 *   },
 *   MaxResults: Number("int"),
 *   BiasPosition: [ // Position
 *     Number("double"),
 *   ],
 *   Filter: { // GeocodeFilter
 *     IncludeCountries: [ // CountryCodeList
 *       "STRING_VALUE",
 *     ],
 *     IncludePlaceTypes: [ // PlaceTypeList
 *       "STRING_VALUE",
 *     ],
 *   },
 *   AdditionalFeatures: [ // GeocodeAdditionalFeatureList
 *     "STRING_VALUE",
 *   ],
 *   Language: "STRING_VALUE",
 *   PoliticalView: "STRING_VALUE",
 *   IntendedUse: "STRING_VALUE",
 *   Key: "STRING_VALUE",
 *   KeyHeader: "STRING_VALUE",
 * };
 * const command = new GeocodeCommand(input);
 * const response = await client.send(command);
 * // { // GeocodeResponse
 * //   PricingBucket: "STRING_VALUE", // required
 * //   ResultItems: [ // GeocodeResultItemList
 * //     { // GeocodeResultItem
 * //       PlaceId: "STRING_VALUE", // required
 * //       PlaceType: "STRING_VALUE", // required
 * //       Title: "STRING_VALUE", // required
 * //       Address: { // Address
 * //         Label: "STRING_VALUE",
 * //         Country: { // Country
 * //           Code2: "STRING_VALUE",
 * //           Code3: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Region: { // Region
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         SubRegion: { // SubRegion
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Locality: "STRING_VALUE",
 * //         District: "STRING_VALUE",
 * //         SubDistrict: "STRING_VALUE",
 * //         PostalCode: "STRING_VALUE",
 * //         Block: "STRING_VALUE",
 * //         SubBlock: "STRING_VALUE",
 * //         Intersection: [ // IntersectionList
 * //           "STRING_VALUE",
 * //         ],
 * //         Street: "STRING_VALUE",
 * //         StreetComponents: [ // StreetComponentsList
 * //           { // StreetComponents
 * //             BaseName: "STRING_VALUE",
 * //             Type: "STRING_VALUE",
 * //             TypePlacement: "STRING_VALUE",
 * //             TypeSeparator: "STRING_VALUE",
 * //             Prefix: "STRING_VALUE",
 * //             Suffix: "STRING_VALUE",
 * //             Direction: "STRING_VALUE",
 * //             Language: "STRING_VALUE",
 * //           },
 * //         ],
 * //         AddressNumber: "STRING_VALUE",
 * //         Building: "STRING_VALUE",
 * //       },
 * //       AddressNumberCorrected: true || false,
 * //       PostalCodeDetails: [ // PostalCodeDetailsList
 * //         { // PostalCodeDetails
 * //           PostalCode: "STRING_VALUE",
 * //           PostalAuthority: "STRING_VALUE",
 * //           PostalCodeType: "STRING_VALUE",
 * //           UspsZip: { // UspsZip
 * //             ZipClassificationCode: "STRING_VALUE",
 * //           },
 * //           UspsZipPlus4: { // UspsZipPlus4
 * //             RecordTypeCode: "STRING_VALUE",
 * //           },
 * //         },
 * //       ],
 * //       Position: [ // Position
 * //         Number("double"),
 * //       ],
 * //       Distance: Number("long"),
 * //       MapView: [ // BoundingBox
 * //         Number("double"),
 * //       ],
 * //       Categories: [ // CategoryList
 * //         { // Category
 * //           Id: "STRING_VALUE", // required
 * //           Name: "STRING_VALUE", // required
 * //           LocalizedName: "STRING_VALUE",
 * //           Primary: true || false,
 * //         },
 * //       ],
 * //       FoodTypes: [ // FoodTypeList
 * //         { // FoodType
 * //           LocalizedName: "STRING_VALUE", // required
 * //           Id: "STRING_VALUE",
 * //           Primary: true || false,
 * //         },
 * //       ],
 * //       AccessPoints: [ // AccessPointList
 * //         { // AccessPoint
 * //           Position: [
 * //             Number("double"),
 * //           ],
 * //         },
 * //       ],
 * //       TimeZone: { // TimeZone
 * //         Name: "STRING_VALUE", // required
 * //         Offset: "STRING_VALUE",
 * //         OffsetSeconds: Number("long"),
 * //       },
 * //       PoliticalView: "STRING_VALUE",
 * //       MatchScores: { // MatchScoreDetails
 * //         Overall: Number("double"),
 * //         Components: { // ComponentMatchScores
 * //           Title: Number("double"),
 * //           Address: { // AddressComponentMatchScores
 * //             Country: Number("double"),
 * //             Region: Number("double"),
 * //             SubRegion: Number("double"),
 * //             Locality: Number("double"),
 * //             District: Number("double"),
 * //             SubDistrict: Number("double"),
 * //             PostalCode: Number("double"),
 * //             Block: Number("double"),
 * //             SubBlock: Number("double"),
 * //             Intersection: [ // MatchScoreList
 * //               Number("double"),
 * //             ],
 * //             AddressNumber: Number("double"),
 * //             Building: Number("double"),
 * //           },
 * //         },
 * //       },
 * //       ParsedQuery: { // GeocodeParsedQuery
 * //         Title: [ // ParsedQueryComponentList
 * //           { // ParsedQueryComponent
 * //             StartIndex: Number("int"),
 * //             EndIndex: Number("int"),
 * //             Value: "STRING_VALUE",
 * //             QueryComponent: "STRING_VALUE",
 * //           },
 * //         ],
 * //         Address: { // GeocodeParsedQueryAddressComponents
 * //           Country: [
 * //             {
 * //               StartIndex: Number("int"),
 * //               EndIndex: Number("int"),
 * //               Value: "STRING_VALUE",
 * //               QueryComponent: "STRING_VALUE",
 * //             },
 * //           ],
 * //           Region: [
 * //             {
 * //               StartIndex: Number("int"),
 * //               EndIndex: Number("int"),
 * //               Value: "STRING_VALUE",
 * //               QueryComponent: "STRING_VALUE",
 * //             },
 * //           ],
 * //           SubRegion: [
 * //             {
 * //               StartIndex: Number("int"),
 * //               EndIndex: Number("int"),
 * //               Value: "STRING_VALUE",
 * //               QueryComponent: "STRING_VALUE",
 * //             },
 * //           ],
 * //           Locality: [
 * //             {
 * //               StartIndex: Number("int"),
 * //               EndIndex: Number("int"),
 * //               Value: "STRING_VALUE",
 * //               QueryComponent: "STRING_VALUE",
 * //             },
 * //           ],
 * //           District: "<ParsedQueryComponentList>",
 * //           SubDistrict: "<ParsedQueryComponentList>",
 * //           PostalCode: "<ParsedQueryComponentList>",
 * //           Block: "<ParsedQueryComponentList>",
 * //           SubBlock: "<ParsedQueryComponentList>",
 * //           Street: "<ParsedQueryComponentList>",
 * //           AddressNumber: "<ParsedQueryComponentList>",
 * //           Building: "<ParsedQueryComponentList>",
 * //           Unit: "<ParsedQueryComponentList>",
 * //         },
 * //       },
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param GeocodeCommandInput - {@link GeocodeCommandInput}
 * @returns {@link GeocodeCommandOutput}
 * @see {@link GeocodeCommandInput} for command's `input` shape.
 * @see {@link GeocodeCommandOutput} for command's `response` shape.
 * @see {@link GeoPlacesClientResolvedConfig | config} for GeoPlacesClient's `config` shape.
 *
 * @throws {@link ValidationException} (client fault)
 *
 * @throws {@link AccessDeniedException} (client fault)
 *
 * @throws {@link ThrottlingException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link GeoPlacesServiceException}
 * <p>Base exception class for all service exceptions from GeoPlaces service.</p>
 *
 */
export declare class GeocodeCommand extends $Command<GeocodeCommandInput, GeocodeCommandOutput, GeoPlacesClientResolvedConfig> {
    readonly input: GeocodeCommandInput;
    /**
     * @public
     */
    constructor(input: GeocodeCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: GeoPlacesClientResolvedConfig, options?: __HttpHandlerOptions): Handler<GeocodeCommandInput, GeocodeCommandOutput>;
    /**
     * @internal
     */
    private serialize;
    /**
     * @internal
     */
    private deserialize;
}
