import { GeoPlacesClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GeoPlacesClient";
import { ReverseGeocodeRequest, ReverseGeocodeResponse } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link ReverseGeocodeCommand}.
 */
export interface ReverseGeocodeCommandInput extends ReverseGeocodeRequest {
}
/**
 * @public
 *
 * The output of {@link ReverseGeocodeCommand}.
 */
export interface ReverseGeocodeCommandOutput extends ReverseGeocodeResponse, __MetadataBearer {
}
/**
 * @internal
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GeoPlacesClient, ReverseGeocodeCommand } from "@amzn/geoplaces-client"; // ES Modules import
 * // const { GeoPlacesClient, ReverseGeocodeCommand } = require("@amzn/geoplaces-client"); // CommonJS import
 * const client = new GeoPlacesClient(config);
 * const input = { // ReverseGeocodeRequest
 *   SearchPosition: [ // Position // required
 *     Number("double"),
 *   ],
 *   SearchRadius: Number("long"),
 *   MaxResults: Number("int"),
 *   FilterPlaceTypes: [ // PlaceTypeList
 *     "STRING_VALUE",
 *   ],
 *   AdditionalFeatures: [ // ReverseGeocodeAdditionalFeatureList
 *     "STRING_VALUE",
 *   ],
 *   Language: "STRING_VALUE",
 *   PoliticalView: "STRING_VALUE",
 *   IntendedUse: "STRING_VALUE",
 *   Key: "STRING_VALUE",
 *   KeyHeader: "STRING_VALUE",
 * };
 * const command = new ReverseGeocodeCommand(input);
 * const response = await client.send(command);
 * // { // ReverseGeocodeResponse
 * //   PricingTier: "STRING_VALUE", // required
 * //   ResultItems: [ // ReverseGeocodeResultItemList
 * //     { // ReverseGeocodeResultItem
 * //       PlaceId: "STRING_VALUE", // required
 * //       PlaceType: "STRING_VALUE", // required
 * //       Title: "STRING_VALUE", // required
 * //       Address: { // Address
 * //         Label: "STRING_VALUE",
 * //         Country: { // Country
 * //           Code2: "STRING_VALUE",
 * //           Code3: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Region: { // Region
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         SubRegion: { // SubRegion
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Locality: "STRING_VALUE",
 * //         District: "STRING_VALUE",
 * //         SubDistrict: "STRING_VALUE",
 * //         PostalCode: "STRING_VALUE",
 * //         Block: "STRING_VALUE",
 * //         SubBlock: "STRING_VALUE",
 * //         Intersection: [ // IntersectionList
 * //           "STRING_VALUE",
 * //         ],
 * //         Street: "STRING_VALUE",
 * //         StreetComponents: [ // StreetComponentsList
 * //           { // StreetComponents
 * //             BaseName: "STRING_VALUE",
 * //             Type: "STRING_VALUE",
 * //             TypePlacement: "STRING_VALUE",
 * //             TypeSeparator: "STRING_VALUE",
 * //             Prefix: "STRING_VALUE",
 * //             Suffix: "STRING_VALUE",
 * //             Direction: "STRING_VALUE",
 * //             Language: "STRING_VALUE",
 * //           },
 * //         ],
 * //         AddressNumber: "STRING_VALUE",
 * //         Building: "STRING_VALUE",
 * //       },
 * //       AddressNumberCorrected: true || false,
 * //       PostalCodeDetails: [ // PostalCodeDetailsList
 * //         { // PostalCodeDetails
 * //           PostalCode: "STRING_VALUE",
 * //           PostalAuthority: "STRING_VALUE",
 * //           PostalCodeType: "STRING_VALUE",
 * //           UspsZip: { // UspsZip
 * //             ZipClassificationCode: "STRING_VALUE",
 * //           },
 * //           UspsZipPlus4: { // UspsZipPlus4
 * //             RecordTypeCode: "STRING_VALUE",
 * //           },
 * //         },
 * //       ],
 * //       Position: [ // Position
 * //         Number("double"),
 * //       ],
 * //       Distance: Number("long"),
 * //       MapView: [ // BoundingBox
 * //         Number("double"),
 * //       ],
 * //       Categories: [ // CategoryList
 * //         { // Category
 * //           Name: "STRING_VALUE", // required
 * //           LocalizedName: "STRING_VALUE", // required
 * //           Primary: true || false, // required
 * //         },
 * //       ],
 * //       FoodTypes: [ // FoodTypeList
 * //         { // FoodType
 * //           LocalizedName: "STRING_VALUE", // required
 * //           Primary: true || false,
 * //         },
 * //       ],
 * //       AccessPoints: [ // AccessPointList
 * //         { // AccessPoint
 * //           Position: [
 * //             Number("double"),
 * //           ],
 * //         },
 * //       ],
 * //       TimeZone: { // TimeZone
 * //         Name: "STRING_VALUE", // required
 * //         Offset: "STRING_VALUE",
 * //         OffsetSeconds: Number("long"),
 * //       },
 * //       PoliticalView: "STRING_VALUE",
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param ReverseGeocodeCommandInput - {@link ReverseGeocodeCommandInput}
 * @returns {@link ReverseGeocodeCommandOutput}
 * @see {@link ReverseGeocodeCommandInput} for command's `input` shape.
 * @see {@link ReverseGeocodeCommandOutput} for command's `response` shape.
 * @see {@link GeoPlacesClientResolvedConfig | config} for GeoPlacesClient's `config` shape.
 *
 * @throws {@link ValidationException} (client fault)
 *
 * @throws {@link AccessDeniedException} (client fault)
 *
 * @throws {@link ThrottlingException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link GeoPlacesServiceException}
 * <p>Base exception class for all service exceptions from GeoPlaces service.</p>
 *
 */
export declare class ReverseGeocodeCommand extends $Command<ReverseGeocodeCommandInput, ReverseGeocodeCommandOutput, GeoPlacesClientResolvedConfig> {
    readonly input: ReverseGeocodeCommandInput;
    /**
     * @public
     */
    constructor(input: ReverseGeocodeCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: GeoPlacesClientResolvedConfig, options?: __HttpHandlerOptions): Handler<ReverseGeocodeCommandInput, ReverseGeocodeCommandOutput>;
    /**
     * @internal
     */
    private serialize;
    /**
     * @internal
     */
    private deserialize;
}
