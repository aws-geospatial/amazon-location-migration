import { GeoPlacesClientResolvedConfig, ServiceInputTypes, ServiceOutputTypes } from "../GeoPlacesClient";
import { SearchNearbyRequest, SearchNearbyResponse } from "../models/models_0";
import { Command as $Command } from "@smithy/smithy-client";
import { Handler, MiddlewareStack, HttpHandlerOptions as __HttpHandlerOptions, MetadataBearer as __MetadataBearer } from "@smithy/types";
/**
 * @public
 */
export { __MetadataBearer, $Command };
/**
 * @public
 *
 * The input for {@link SearchNearbyCommand}.
 */
export interface SearchNearbyCommandInput extends SearchNearbyRequest {
}
/**
 * @public
 *
 * The output of {@link SearchNearbyCommand}.
 */
export interface SearchNearbyCommandOutput extends SearchNearbyResponse, __MetadataBearer {
}
/**
 * @internal
 *
 * @example
 * Use a bare-bones client and the command you need to make an API call.
 * ```javascript
 * import { GeoPlacesClient, SearchNearbyCommand } from "@amzn/geoplaces-client"; // ES Modules import
 * // const { GeoPlacesClient, SearchNearbyCommand } = require("@amzn/geoplaces-client"); // CommonJS import
 * const client = new GeoPlacesClient(config);
 * const input = { // SearchNearbyRequest
 *   SearchPosition: [ // Position // required
 *     Number("double"),
 *   ],
 *   SearchRadius: Number("long"),
 *   MaxResults: Number("int"),
 *   FilterBoundingBox: [ // BoundingBox
 *     Number("double"),
 *   ],
 *   FilterCountries: [ // CountryCodeList
 *     "STRING_VALUE",
 *   ],
 *   FilterCategories: [ // FilterCategoryList
 *     "STRING_VALUE",
 *   ],
 *   AdditionalFeatures: [ // SearchNearbyAdditionalFeatureList
 *     "STRING_VALUE",
 *   ],
 *   Language: "STRING_VALUE",
 *   PoliticalView: "STRING_VALUE",
 *   IntendedUse: "STRING_VALUE",
 *   Key: "STRING_VALUE",
 *   KeyHeader: "STRING_VALUE",
 * };
 * const command = new SearchNearbyCommand(input);
 * const response = await client.send(command);
 * // { // SearchNearbyResponse
 * //   PricingTier: "STRING_VALUE", // required
 * //   ResultItems: [ // SearchNearbyResultItemList
 * //     { // SearchNearbyResultItem
 * //       PlaceId: "STRING_VALUE", // required
 * //       PlaceType: "STRING_VALUE", // required
 * //       Title: "STRING_VALUE", // required
 * //       Address: { // Address
 * //         Label: "STRING_VALUE",
 * //         Country: { // Country
 * //           Code2: "STRING_VALUE",
 * //           Code3: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Region: { // Region
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         SubRegion: { // SubRegion
 * //           Code: "STRING_VALUE",
 * //           Name: "STRING_VALUE",
 * //         },
 * //         Locality: "STRING_VALUE",
 * //         District: "STRING_VALUE",
 * //         SubDistrict: "STRING_VALUE",
 * //         PostalCode: "STRING_VALUE",
 * //         Block: "STRING_VALUE",
 * //         SubBlock: "STRING_VALUE",
 * //         Intersection: [ // IntersectionList
 * //           "STRING_VALUE",
 * //         ],
 * //         Street: "STRING_VALUE",
 * //         StreetComponents: [ // StreetComponentsList
 * //           { // StreetComponents
 * //             BaseName: "STRING_VALUE",
 * //             Type: "STRING_VALUE",
 * //             TypePlacement: "STRING_VALUE",
 * //             TypeSeparator: "STRING_VALUE",
 * //             Prefix: "STRING_VALUE",
 * //             Suffix: "STRING_VALUE",
 * //             Direction: "STRING_VALUE",
 * //             Language: "STRING_VALUE",
 * //           },
 * //         ],
 * //         AddressNumber: "STRING_VALUE",
 * //         Building: "STRING_VALUE",
 * //       },
 * //       AddressNumberCorrected: true || false,
 * //       Position: [ // Position
 * //         Number("double"),
 * //       ],
 * //       Distance: Number("long"),
 * //       MapView: [ // BoundingBox
 * //         Number("double"),
 * //       ],
 * //       Categories: [ // CategoryList
 * //         { // Category
 * //           Name: "STRING_VALUE", // required
 * //           LocalizedName: "STRING_VALUE", // required
 * //           Primary: true || false, // required
 * //         },
 * //       ],
 * //       FoodTypes: [ // FoodTypeList
 * //         { // FoodType
 * //           LocalizedName: "STRING_VALUE", // required
 * //           Primary: true || false,
 * //         },
 * //       ],
 * //       Chains: [ // ChainList
 * //         "STRING_VALUE",
 * //       ],
 * //       Contacts: { // Contacts
 * //         Phones: [ // ContactDetailsList
 * //           { // ContactDetails
 * //             Label: "STRING_VALUE",
 * //             Value: "STRING_VALUE",
 * //           },
 * //         ],
 * //         Faxes: [
 * //           {
 * //             Label: "STRING_VALUE",
 * //             Value: "STRING_VALUE",
 * //           },
 * //         ],
 * //         Websites: [
 * //           {
 * //             Label: "STRING_VALUE",
 * //             Value: "STRING_VALUE",
 * //           },
 * //         ],
 * //         Emails: [
 * //           {
 * //             Label: "STRING_VALUE",
 * //             Value: "STRING_VALUE",
 * //           },
 * //         ],
 * //       },
 * //       OpeningHours: [ // OpeningHoursList
 * //         { // OpeningHours
 * //           Display: [ // OpeningHoursDisplayList
 * //             "STRING_VALUE",
 * //           ],
 * //           OpenNow: true || false,
 * //           Components: [ // OpeningHoursComponentsList
 * //             { // OpeningHoursComponents
 * //               OpenTime: "STRING_VALUE",
 * //               OpenDuration: "STRING_VALUE",
 * //               Recurrence: "STRING_VALUE",
 * //             },
 * //           ],
 * //         },
 * //       ],
 * //       AccessPoints: [ // AccessPointList
 * //         { // AccessPoint
 * //           Position: [
 * //             Number("double"),
 * //           ],
 * //         },
 * //       ],
 * //       AccessRestrictions: [ // AccessRestrictionList
 * //         { // AccessRestriction
 * //           Restricted: true || false,
 * //         },
 * //       ],
 * //       TimeZone: { // TimeZone
 * //         Name: "STRING_VALUE", // required
 * //         Offset: "STRING_VALUE",
 * //         OffsetSeconds: Number("long"),
 * //       },
 * //       PoliticalView: "STRING_VALUE",
 * //       Phonemes: { // PhonemeDetails
 * //         Title: [ // PhonemeTranscriptionList
 * //           { // PhonemeTranscription
 * //             Value: "STRING_VALUE",
 * //             Language: "STRING_VALUE",
 * //             Preferred: true || false,
 * //           },
 * //         ],
 * //         Address: { // AddressComponentPhonemes
 * //           Country: [
 * //             {
 * //               Value: "STRING_VALUE",
 * //               Language: "STRING_VALUE",
 * //               Preferred: true || false,
 * //             },
 * //           ],
 * //           Region: [
 * //             {
 * //               Value: "STRING_VALUE",
 * //               Language: "STRING_VALUE",
 * //               Preferred: true || false,
 * //             },
 * //           ],
 * //           SubRegion: [
 * //             {
 * //               Value: "STRING_VALUE",
 * //               Language: "STRING_VALUE",
 * //               Preferred: true || false,
 * //             },
 * //           ],
 * //           Locality: [
 * //             {
 * //               Value: "STRING_VALUE",
 * //               Language: "STRING_VALUE",
 * //               Preferred: true || false,
 * //             },
 * //           ],
 * //           District: "<PhonemeTranscriptionList>",
 * //           SubDistrict: "<PhonemeTranscriptionList>",
 * //           Block: "<PhonemeTranscriptionList>",
 * //           SubBlock: "<PhonemeTranscriptionList>",
 * //           Street: "<PhonemeTranscriptionList>",
 * //         },
 * //       },
 * //     },
 * //   ],
 * // };
 *
 * ```
 *
 * @param SearchNearbyCommandInput - {@link SearchNearbyCommandInput}
 * @returns {@link SearchNearbyCommandOutput}
 * @see {@link SearchNearbyCommandInput} for command's `input` shape.
 * @see {@link SearchNearbyCommandOutput} for command's `response` shape.
 * @see {@link GeoPlacesClientResolvedConfig | config} for GeoPlacesClient's `config` shape.
 *
 * @throws {@link ValidationException} (client fault)
 *
 * @throws {@link AccessDeniedException} (client fault)
 *
 * @throws {@link ThrottlingException} (client fault)
 *
 * @throws {@link InternalServerException} (server fault)
 *
 * @throws {@link GeoPlacesServiceException}
 * <p>Base exception class for all service exceptions from GeoPlaces service.</p>
 *
 */
export declare class SearchNearbyCommand extends $Command<SearchNearbyCommandInput, SearchNearbyCommandOutput, GeoPlacesClientResolvedConfig> {
    readonly input: SearchNearbyCommandInput;
    /**
     * @public
     */
    constructor(input: SearchNearbyCommandInput);
    /**
     * @internal
     */
    resolveMiddleware(clientStack: MiddlewareStack<ServiceInputTypes, ServiceOutputTypes>, configuration: GeoPlacesClientResolvedConfig, options?: __HttpHandlerOptions): Handler<SearchNearbyCommandInput, SearchNearbyCommandOutput>;
    /**
     * @internal
     */
    private serialize;
    /**
     * @internal
     */
    private deserialize;
}
