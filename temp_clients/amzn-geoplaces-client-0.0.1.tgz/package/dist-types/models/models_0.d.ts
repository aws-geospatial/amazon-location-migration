import { GeoPlacesServiceException as __BaseException } from "./GeoPlacesServiceException";
import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/smithy-client";
/**
 * @public
 */
export declare class AccessDeniedException extends __BaseException {
    readonly name: "AccessDeniedException";
    readonly $fault: "client";
    Message: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<AccessDeniedException, __BaseException>);
}
/**
 * @public
 */
export declare class InternalServerException extends __BaseException {
    readonly name: "InternalServerException";
    readonly $fault: "server";
    $retryable: {};
    Message: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<InternalServerException, __BaseException>);
}
/**
 * @public
 */
export declare class ThrottlingException extends __BaseException {
    readonly name: "ThrottlingException";
    readonly $fault: "client";
    $retryable: {};
    Message: string | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<ThrottlingException, __BaseException>);
}
/**
 * @public
 */
export interface ValidationExceptionField {
    Name: string | undefined;
    Message: string | undefined;
}
/**
 * @public
 */
export type ValidationExceptionReason = "CannotParse" | "FieldValidationFailed" | "Missing" | "Other" | "UnknownOperation";
/**
 * @public
 */
export declare class ValidationException extends __BaseException {
    readonly name: "ValidationException";
    readonly $fault: "client";
    Message: string | undefined;
    Reason: ValidationExceptionReason | undefined;
    FieldList: (ValidationExceptionField)[] | undefined;
    /**
     * @internal
     */
    constructor(opts: __ExceptionOptionType<ValidationException, __BaseException>);
}
/**
 * @public
 */
export interface AccessPoint {
    Position?: (number)[];
}
/**
 * @internal
 */
export declare const AccessPointFilterSensitiveLog: (obj: AccessPoint) => any;
/**
 * @public
 */
export interface AccessRestriction {
    Restricted?: boolean;
}
/**
 * @public
 */
export interface Country {
    Code2?: string;
    Code3?: string;
    Name?: string;
}
/**
 * @public
 */
export interface Region {
    Code?: string;
    Name?: string;
}
/**
 * @public
 */
export type TypePlacement = "AfterBaseName" | "BeforeBaseName";
/**
 * @public
 */
export interface StreetComponents {
    BaseName?: string;
    Type?: string;
    TypePlacement?: TypePlacement;
    TypeSeparator?: string;
    Prefix?: string;
    Suffix?: string;
    Direction?: string;
    Language?: string;
}
/**
 * @public
 */
export interface SubRegion {
    Code?: string;
    Name?: string;
}
/**
 * @public
 */
export interface Address {
    Label?: string;
    Country?: Country;
    Region?: Region;
    SubRegion?: SubRegion;
    Locality?: string;
    District?: string;
    SubDistrict?: string;
    PostalCode?: string;
    Block?: string;
    SubBlock?: string;
    Intersection?: (string)[];
    Street?: string;
    StreetComponents?: (StreetComponents)[];
    AddressNumber?: string;
    Building?: string;
}
/**
 * @public
 */
export interface AddressComponentMatchScores {
    Country?: number;
    Region?: number;
    SubRegion?: number;
    Locality?: number;
    District?: number;
    SubDistrict?: number;
    PostalCode?: number;
    Block?: number;
    SubBlock?: number;
    Intersection?: (number)[];
    AddressNumber?: number;
    Building?: number;
}
/**
 * @public
 */
export interface PhonemeTranscription {
    Value?: string;
    Language?: string;
    Preferred?: boolean;
}
/**
 * @public
 */
export interface AddressComponentPhonemes {
    Country?: (PhonemeTranscription)[];
    Region?: (PhonemeTranscription)[];
    SubRegion?: (PhonemeTranscription)[];
    Locality?: (PhonemeTranscription)[];
    District?: (PhonemeTranscription)[];
    SubDistrict?: (PhonemeTranscription)[];
    Block?: (PhonemeTranscription)[];
    SubBlock?: (PhonemeTranscription)[];
    Street?: (PhonemeTranscription)[];
}
/**
 * @public
 */
export type AutocompleteAdditionalFeature = "PLACEHOLDER";
/**
 * @public
 */
export interface FilterCircle {
    Center: (number)[] | undefined;
    Radius: number | undefined;
}
/**
 * @internal
 */
export declare const FilterCircleFilterSensitiveLog: (obj: FilterCircle) => any;
/**
 * @public
 */
export type PlaceType = "Block" | "Country" | "District" | "InterpolatedAddress" | "Intersection" | "Locality" | "PointAddress" | "PointOfInterest" | "PostalCodeArea" | "PostalCodePoint" | "Region" | "Street" | "SubBlock" | "SubDistrict" | "SubRegion";
/**
 * @public
 */
export type IntendedUse = "SingleUse" | "Storage";
/**
 * @public
 */
export type PostalCodeMode = "EnumerateSpannedLocalities" | "MergeAllSpannedLocalities";
/**
 * @public
 */
export interface AutocompleteRequest {
    Query: string | undefined;
    MaxResults?: number;
    BiasPosition?: (number)[];
    FilterBoundingBox?: (number)[];
    FilterCircle?: FilterCircle;
    FilterCountries?: (string)[];
    FilterPlaceTypes?: (PlaceType)[];
    PostalCodeMode?: PostalCodeMode;
    AdditionalFeatures?: (AutocompleteAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const AutocompleteRequestFilterSensitiveLog: (obj: AutocompleteRequest) => any;
/**
 * @public
 */
export interface Highlight {
    StartIndex?: number;
    EndIndex?: number;
}
/**
 * @public
 */
export interface CountryHighlights {
    Code?: (Highlight)[];
    Name?: (Highlight)[];
}
/**
 * @public
 */
export interface RegionHighlights {
    Code?: (Highlight)[];
    Name?: (Highlight)[];
}
/**
 * @public
 */
export interface SubRegionHighlights {
    Code?: (Highlight)[];
    Name?: (Highlight)[];
}
/**
 * @public
 */
export interface AutocompleteAddressHighlights {
    Label?: (Highlight)[];
    Country?: CountryHighlights;
    Region?: RegionHighlights;
    SubRegion?: SubRegionHighlights;
    Locality?: (Highlight)[];
    District?: (Highlight)[];
    SubDistrict?: (Highlight)[];
    Street?: (Highlight)[];
    PostalCode?: (Highlight)[];
    AddressNumber?: (Highlight)[];
}
/**
 * @public
 */
export interface AutocompleteHighlights {
    Title?: (Highlight)[];
    Address?: AutocompleteAddressHighlights;
}
/**
 * @public
 */
export interface AutocompleteResultItem {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    Address?: Address;
    Distance?: number;
    Language?: string;
    PoliticalView?: string;
    Highlights?: AutocompleteHighlights;
}
/**
 * @public
 */
export interface AutocompleteResponse {
    PricingTier: string | undefined;
    ResultItems?: (AutocompleteResultItem)[];
}
/**
 * @public
 */
export interface Category {
    Name: string | undefined;
    LocalizedName: string | undefined;
    Primary: boolean | undefined;
}
/**
 * @public
 */
export interface ComponentMatchScores {
    Title?: number;
    Address?: AddressComponentMatchScores;
}
/**
 * @public
 */
export interface ContactDetails {
    Label?: string;
    Value?: string;
}
/**
 * @public
 */
export interface Contacts {
    Phones?: (ContactDetails)[];
    Faxes?: (ContactDetails)[];
    Websites?: (ContactDetails)[];
    Emails?: (ContactDetails)[];
}
/**
 * @public
 */
export interface FoodType {
    LocalizedName: string | undefined;
    Primary?: boolean;
}
/**
 * @public
 */
export type GeocodeAdditionalFeature = "ParsedQuery" | "TimeZone";
/**
 * @public
 */
export interface GeocodeQueryComponents {
    Country?: string;
    Region?: string;
    SubRegion?: string;
    Locality?: string;
    District?: string;
    Street?: string;
    AddressNumber?: string;
    PostalCode?: string;
}
/**
 * @internal
 */
export declare const GeocodeQueryComponentsFilterSensitiveLog: (obj: GeocodeQueryComponents) => any;
/**
 * @public
 */
export interface GeocodeRequest {
    Query?: string;
    QueryComponents?: GeocodeQueryComponents;
    MaxResults?: number;
    BiasPosition?: (number)[];
    FilterCountries?: (string)[];
    FilterPlaceTypes?: (PlaceType)[];
    AdditionalFeatures?: (GeocodeAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const GeocodeRequestFilterSensitiveLog: (obj: GeocodeRequest) => any;
/**
 * @public
 */
export interface MatchScoreDetails {
    Overall?: number;
    Components?: ComponentMatchScores;
}
/**
 * @public
 */
export interface ParsedQueryComponent {
    StartIndex?: number;
    EndIndex?: number;
    Value?: string;
    QueryComponent?: string;
}
/**
 * @public
 */
export interface ParsedQueryAddressComponents {
    Country?: (ParsedQueryComponent)[];
    Region?: (ParsedQueryComponent)[];
    SubRegion?: (ParsedQueryComponent)[];
    Locality?: (ParsedQueryComponent)[];
    District?: (ParsedQueryComponent)[];
    SubDistrict?: (ParsedQueryComponent)[];
    PostalCode?: (ParsedQueryComponent)[];
    Block?: (ParsedQueryComponent)[];
    SubBlock?: (ParsedQueryComponent)[];
    Street?: (ParsedQueryComponent)[];
    AddressNumber?: (ParsedQueryComponent)[];
    Building?: (ParsedQueryComponent)[];
    Unit?: (ParsedQueryComponent)[];
}
/**
 * @public
 */
export interface ParsedQuery {
    Title?: (ParsedQueryComponent)[];
    Address?: ParsedQueryAddressComponents;
}
/**
 * @public
 */
export type PostalAuthority = "Usps";
/**
 * @public
 */
export type PostalCodeType = "UspsZip" | "UspsZipPlus4";
/**
 * @public
 */
export type ZipClassificationCode = "Military" | "PostOfficeBoxes" | "Unique";
/**
 * @public
 */
export interface UspsZip {
    ZipClassificationCode?: ZipClassificationCode;
}
/**
 * @public
 */
export type RecordTypeCode = "Firm" | "General" | "HighRise" | "PostOfficeBox" | "Rural" | "Street";
/**
 * @public
 */
export interface UspsZipPlus4 {
    RecordTypeCode?: RecordTypeCode;
}
/**
 * @public
 */
export interface PostalCodeDetails {
    PostalCode?: string;
    PostalAuthority?: PostalAuthority;
    PostalCodeType?: PostalCodeType;
    UspsZip?: UspsZip;
    UspsZipPlus4?: UspsZipPlus4;
}
/**
 * @public
 */
export interface TimeZone {
    Name: string | undefined;
    Offset?: string;
    OffsetSeconds?: number;
}
/**
 * @public
 */
export interface GeocodeResultItem {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: (PostalCodeDetails)[];
    Position?: (number)[];
    Distance?: number;
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    AccessPoints?: (AccessPoint)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
    MatchScores?: MatchScoreDetails;
    ParsedQuery?: ParsedQuery;
}
/**
 * @internal
 */
export declare const GeocodeResultItemFilterSensitiveLog: (obj: GeocodeResultItem) => any;
/**
 * @public
 */
export interface GeocodeResponse {
    PricingTier: string | undefined;
    ResultItems?: (GeocodeResultItem)[];
}
/**
 * @internal
 */
export declare const GeocodeResponseFilterSensitiveLog: (obj: GeocodeResponse) => any;
/**
 * @public
 */
export type GetPlaceAdditionalFeature = "Phonemes" | "TimeZone";
/**
 * @public
 */
export interface GetPlaceRequest {
    PlaceId: string | undefined;
    AdditionalFeatures?: (GetPlaceAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const GetPlaceRequestFilterSensitiveLog: (obj: GetPlaceRequest) => any;
/**
 * @public
 */
export interface OpeningHoursComponents {
    OpenTime?: string;
    OpenDuration?: string;
    Recurrence?: string;
}
/**
 * @public
 */
export interface OpeningHours {
    Display?: (string)[];
    OpenNow?: boolean;
    Components?: (OpeningHoursComponents)[];
}
/**
 * @public
 */
export interface PhonemeDetails {
    Title?: (PhonemeTranscription)[];
    Address?: AddressComponentPhonemes;
}
/**
 * @public
 */
export interface GetPlaceResponse {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    PricingTier: string | undefined;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: (PostalCodeDetails)[];
    Position?: (number)[];
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    Chains?: (string)[];
    Contacts?: Contacts;
    OpeningHours?: (OpeningHours)[];
    AccessPoints?: (AccessPoint)[];
    AccessRestrictions?: (AccessRestriction)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
    Phonemes?: PhonemeDetails;
}
/**
 * @internal
 */
export declare const GetPlaceResponseFilterSensitiveLog: (obj: GetPlaceResponse) => any;
/**
 * @public
 */
export type ReverseGeocodeAdditionalFeature = "TimeZone";
/**
 * @public
 */
export interface ReverseGeocodeRequest {
    SearchPosition: (number)[] | undefined;
    SearchRadius?: number;
    MaxResults?: number;
    FilterPlaceTypes?: (PlaceType)[];
    AdditionalFeatures?: (ReverseGeocodeAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const ReverseGeocodeRequestFilterSensitiveLog: (obj: ReverseGeocodeRequest) => any;
/**
 * @public
 */
export interface ReverseGeocodeResultItem {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    PostalCodeDetails?: (PostalCodeDetails)[];
    Position?: (number)[];
    Distance?: number;
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    AccessPoints?: (AccessPoint)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
}
/**
 * @internal
 */
export declare const ReverseGeocodeResultItemFilterSensitiveLog: (obj: ReverseGeocodeResultItem) => any;
/**
 * @public
 */
export interface ReverseGeocodeResponse {
    PricingTier: string | undefined;
    ResultItems?: (ReverseGeocodeResultItem)[];
}
/**
 * @internal
 */
export declare const ReverseGeocodeResponseFilterSensitiveLog: (obj: ReverseGeocodeResponse) => any;
/**
 * @public
 */
export type SearchNearbyAdditionalFeature = "Phonemes" | "TimeZone";
/**
 * @public
 */
export interface SearchNearbyRequest {
    SearchPosition: (number)[] | undefined;
    SearchRadius?: number;
    MaxResults?: number;
    FilterBoundingBox?: (number)[];
    FilterCountries?: (string)[];
    FilterCategories?: (string)[];
    AdditionalFeatures?: (SearchNearbyAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const SearchNearbyRequestFilterSensitiveLog: (obj: SearchNearbyRequest) => any;
/**
 * @public
 */
export interface SearchNearbyResultItem {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: (number)[];
    Distance?: number;
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    Chains?: (string)[];
    Contacts?: Contacts;
    OpeningHours?: (OpeningHours)[];
    AccessPoints?: (AccessPoint)[];
    AccessRestrictions?: (AccessRestriction)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
    Phonemes?: PhonemeDetails;
}
/**
 * @internal
 */
export declare const SearchNearbyResultItemFilterSensitiveLog: (obj: SearchNearbyResultItem) => any;
/**
 * @public
 */
export interface SearchNearbyResponse {
    PricingTier: string | undefined;
    ResultItems?: (SearchNearbyResultItem)[];
}
/**
 * @internal
 */
export declare const SearchNearbyResponseFilterSensitiveLog: (obj: SearchNearbyResponse) => any;
/**
 * @public
 */
export type SearchTextAdditionalFeature = "Phonemes" | "TimeZone";
/**
 * @public
 */
export interface SearchTextRequest {
    Query?: string;
    QueryId?: string;
    MaxResults?: number;
    BiasPosition?: (number)[];
    FilterBoundingBox?: (number)[];
    FilterCircle?: FilterCircle;
    FilterCountries?: (string)[];
    AdditionalFeatures?: (SearchTextAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const SearchTextRequestFilterSensitiveLog: (obj: SearchTextRequest) => any;
/**
 * @public
 */
export interface SearchTextResultItem {
    PlaceId: string | undefined;
    PlaceType: PlaceType | undefined;
    Title: string | undefined;
    Address?: Address;
    AddressNumberCorrected?: boolean;
    Position?: (number)[];
    Distance?: number;
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    Chains?: (string)[];
    Contacts?: Contacts;
    OpeningHours?: (OpeningHours)[];
    AccessPoints?: (AccessPoint)[];
    AccessRestrictions?: (AccessRestriction)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
    Phonemes?: PhonemeDetails;
}
/**
 * @internal
 */
export declare const SearchTextResultItemFilterSensitiveLog: (obj: SearchTextResultItem) => any;
/**
 * @public
 */
export interface SearchTextResponse {
    PricingTier: string | undefined;
    ResultItems?: (SearchTextResultItem)[];
}
/**
 * @internal
 */
export declare const SearchTextResponseFilterSensitiveLog: (obj: SearchTextResponse) => any;
/**
 * @public
 */
export type SuggestAdditionalFeature = "Phonemes" | "TimeZone";
/**
 * @public
 */
export interface SuggestRequest {
    Query: string | undefined;
    MaxResults?: number;
    MaxQueryRefinements?: number;
    BiasPosition?: (number)[];
    FilterBoundingBox?: (number)[];
    FilterCircle?: FilterCircle;
    FilterCountries?: (string)[];
    AdditionalFeatures?: (SuggestAdditionalFeature)[];
    Language?: string;
    PoliticalView?: string;
    IntendedUse?: IntendedUse;
    Key?: string;
    KeyHeader?: string;
}
/**
 * @internal
 */
export declare const SuggestRequestFilterSensitiveLog: (obj: SuggestRequest) => any;
/**
 * @public
 */
export interface QueryRefinement {
    RefinedTerm: string | undefined;
    OriginalTerm: string | undefined;
    StartIndex: number | undefined;
    EndIndex: number | undefined;
}
/**
 * @public
 */
export interface SuggestAddressHighlights {
    Label?: (Highlight)[];
}
/**
 * @public
 */
export interface SuggestHighlights {
    Title?: (Highlight)[];
    Address?: SuggestAddressHighlights;
}
/**
 * @public
 */
export interface SuggestPlaceResult {
    PlaceId?: string;
    PlaceType?: PlaceType;
    Address?: Address;
    Position?: (number)[];
    Distance?: number;
    MapView?: (number)[];
    Categories?: (Category)[];
    FoodTypes?: (FoodType)[];
    Chains?: (string)[];
    AccessPoints?: (AccessPoint)[];
    AccessRestrictions?: (AccessRestriction)[];
    TimeZone?: TimeZone;
    PoliticalView?: string;
    Phonemes?: PhonemeDetails;
}
/**
 * @internal
 */
export declare const SuggestPlaceResultFilterSensitiveLog: (obj: SuggestPlaceResult) => any;
/**
 * @public
 */
export type QueryType = "Category" | "Chain";
/**
 * @public
 */
export interface SuggestQueryResult {
    QueryId?: string;
    QueryType?: QueryType;
}
/**
 * @public
 */
export type SuggestResultItemType = "Place" | "Query";
/**
 * @public
 */
export interface SuggestResultItem {
    Title: string | undefined;
    SuggestResultItemType: SuggestResultItemType | undefined;
    Place?: SuggestPlaceResult;
    Query?: SuggestQueryResult;
    Highlights?: SuggestHighlights;
}
/**
 * @internal
 */
export declare const SuggestResultItemFilterSensitiveLog: (obj: SuggestResultItem) => any;
/**
 * @public
 */
export interface SuggestResponse {
    PricingTier: string | undefined;
    ResultItems?: (SuggestResultItem)[];
    QueryRefinements?: (QueryRefinement)[];
}
/**
 * @internal
 */
export declare const SuggestResponseFilterSensitiveLog: (obj: SuggestResponse) => any;
