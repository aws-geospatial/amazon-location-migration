import { AutocompleteCommandInput, AutocompleteCommandOutput } from "../commands/AutocompleteCommand";
import { GeocodeCommandInput, GeocodeCommandOutput } from "../commands/GeocodeCommand";
import { GetPlaceCommandInput, GetPlaceCommandOutput } from "../commands/GetPlaceCommand";
import { ReverseGeocodeCommandInput, ReverseGeocodeCommandOutput } from "../commands/ReverseGeocodeCommand";
import { SearchNearbyCommandInput, SearchNearbyCommandOutput } from "../commands/SearchNearbyCommand";
import { SearchTextCommandInput, SearchTextCommandOutput } from "../commands/SearchTextCommand";
import { SuggestCommandInput, SuggestCommandOutput } from "../commands/SuggestCommand";
import { HttpRequest as __HttpRequest, HttpResponse as __HttpResponse } from "@smithy/protocol-http";
import { SerdeContext as __SerdeContext } from "@smithy/types";
/**
 * serializeAws_restJson1AutocompleteCommand
 */
export declare const se_AutocompleteCommand: (input: AutocompleteCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GeocodeCommand
 */
export declare const se_GeocodeCommand: (input: GeocodeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1GetPlaceCommand
 */
export declare const se_GetPlaceCommand: (input: GetPlaceCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1ReverseGeocodeCommand
 */
export declare const se_ReverseGeocodeCommand: (input: ReverseGeocodeCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SearchNearbyCommand
 */
export declare const se_SearchNearbyCommand: (input: SearchNearbyCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SearchTextCommand
 */
export declare const se_SearchTextCommand: (input: SearchTextCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * serializeAws_restJson1SuggestCommand
 */
export declare const se_SuggestCommand: (input: SuggestCommandInput, context: __SerdeContext) => Promise<__HttpRequest>;
/**
 * deserializeAws_restJson1AutocompleteCommand
 */
export declare const de_AutocompleteCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<AutocompleteCommandOutput>;
/**
 * deserializeAws_restJson1GeocodeCommand
 */
export declare const de_GeocodeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GeocodeCommandOutput>;
/**
 * deserializeAws_restJson1GetPlaceCommand
 */
export declare const de_GetPlaceCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<GetPlaceCommandOutput>;
/**
 * deserializeAws_restJson1ReverseGeocodeCommand
 */
export declare const de_ReverseGeocodeCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<ReverseGeocodeCommandOutput>;
/**
 * deserializeAws_restJson1SearchNearbyCommand
 */
export declare const de_SearchNearbyCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SearchNearbyCommandOutput>;
/**
 * deserializeAws_restJson1SearchTextCommand
 */
export declare const de_SearchTextCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SearchTextCommandOutput>;
/**
 * deserializeAws_restJson1SuggestCommand
 */
export declare const de_SuggestCommand: (output: __HttpResponse, context: __SerdeContext) => Promise<SuggestCommandOutput>;
